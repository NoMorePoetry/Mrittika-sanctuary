
import React, { useContext } from 'react';
import { UserContext } from '../context';
import { ARCHETYPES } from '../constants';
import { Shield, Zap, CloudRain, Sun, Sparkles, Gem, Lock } from 'lucide-react';

export const ArchetypeProfile: React.FC = () => {
  const { user } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const archetype = user.archetype ? ARCHETYPES[user.archetype] : ARCHETYPES.lunar_empath;

  const cardBg = isDark ? 'bg-white/5 border-white/10' : 'bg-white border-stone-200 shadow-sm';
  const textBody = isDark ? 'text-slate-300' : 'text-stone-600';
  const heading = isDark ? 'text-white' : 'text-stone-900';

  return (
    <div className="space-y-8 animate-fade-in pb-12">
       <div className={`relative rounded-[2rem] overflow-hidden p-8 md:p-16 ${archetype.colors[0] || 'bg-slate-800'} shadow-2xl`}>
          <div className="relative z-10 text-center">
             <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/10 border border-white/20 backdrop-blur-md mb-8 shadow-lg">
                <Sparkles size={40} className="text-white opacity-90" />
             </div>
             <h1 className={`text-5xl md:text-6xl font-serif ${archetype.colors[1] || 'text-white'} mb-6 drop-shadow-lg`}>{archetype.name}</h1>
             <p className="text-xl md:text-2xl text-white/90 font-light italic max-w-2xl mx-auto leading-relaxed">"{archetype.tagline}"</p>
          </div>
       </div>
       
       <div className={`p-8 rounded-3xl border relative overflow-hidden ${cardBg}`}>
           <div className="flex items-center gap-3 mb-6 text-indigo-400">
               <Gem size={24} />
               <h3 className={`font-serif text-2xl ${heading}`}>Your Soul Satchel</h3>
           </div>
           
           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
               {user.inventory.map((crystal) => (
                   <div key={crystal.id} className={`relative p-4 rounded-2xl border flex flex-col items-center text-center transition-all duration-300 ${crystal.unlocked ? (isDark ? 'bg-white/5 border-white/20' : 'bg-stone-50 border-stone-200') : (isDark ? 'bg-slate-900/50 border-white/5' : 'bg-stone-100 border-stone-200')}`}>
                       <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 ${crystal.unlocked ? (isDark ? 'bg-white/10' : 'bg-white shadow-sm') : 'grayscale opacity-50 bg-stone-300'}`}>
                           <Gem size={20} className={crystal.unlocked ? crystal.color : 'text-stone-500'} />
                       </div>
                       <h4 className={`font-serif text-sm font-medium ${isDark ? 'text-white' : 'text-stone-800'}`}>{crystal.name}</h4>
                       
                       {!crystal.unlocked && (
                           <div className="absolute inset-0 backdrop-blur-[1px] flex flex-col items-center justify-center rounded-2xl opacity-0 hover:opacity-100 transition-opacity p-2 bg-black/40">
                               <Lock size={16} className="text-white mb-2" />
                               <p className="text-[10px] text-white text-center">{crystal.unlockCondition}</p>
                           </div>
                       )}
                   </div>
               ))}
           </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className={`p-8 rounded-3xl ${cardBg}`}>
            <h3 className={`font-serif text-2xl mb-4 ${heading}`}>Core Essence</h3>
            <p className={`leading-relaxed text-lg font-light ${textBody}`}>{archetype.description}</p>
          </div>

          <div className={`p-8 rounded-3xl ${cardBg}`}>
            <h3 className={`font-serif text-2xl mb-4 ${heading}`}>The Shadow</h3>
             <p className={`leading-relaxed text-lg font-light ${textBody}`}>
               Your greatest strength often hides your deepest challenge: <span className="text-rose-400 font-medium">{archetype.shadow}</span>
            </p>
          </div>
       </div>
    </div>
  );
};
