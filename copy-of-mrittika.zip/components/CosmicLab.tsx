
import React, { useState, useRef, useContext } from 'react';
import { MessageCircle, Moon, Camera, Sparkles, Upload, Eye, AlertTriangle, Heart, Zap, Ghost, ScanFace, RefreshCcw } from 'lucide-react';
import { analyzeMessage, analyzeDream, analyzeFaceScan, getAuraReading, analyzeShadowWork } from '../services/geminiService';
import { MessageAnalysisResult, FaceScanResult, AuraResult } from '../types';
import { UserContext } from '../context';
import { ARCHETYPES } from '../constants';

type Tab = 'decoder' | 'dream' | 'facescan' | 'aura' | 'shadow';

export const CosmicLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('decoder');
  const { user } = useContext(UserContext);
  const isDark = user.theme === 'dark';

  const handleTabChange = (tab: Tab) => setActiveTab(tab);

  const activeClass = isDark ? 'bg-stone-700 text-white shadow-md' : 'bg-stone-200 text-stone-900 shadow-sm';
  const inactiveClass = isDark ? 'text-stone-500 hover:text-stone-300' : 'text-stone-500 hover:text-stone-800';

  return (
    <div className="animate-fade-in max-w-4xl mx-auto pb-12">
      <div className="text-center mb-8">
         <h1 className={`text-3xl md:text-4xl font-serif mb-4 ${isDark ? 'text-stone-100' : 'text-stone-900'}`}>Inner Lab</h1>
         <p className="text-stone-500">Deep tools to decode your reality.</p>
      </div>

      <div className="flex justify-center mb-8 flex-wrap gap-2">
         <div className={`flex flex-wrap justify-center gap-2 p-1 rounded-2xl border ${isDark ? 'bg-[#1c1917] border-white/10' : 'bg-white border-stone-200'}`}>
             {[
                 { id: 'decoder', icon: <MessageCircle size={18} />, label: 'Decoder' },
                 { id: 'dream', icon: <Moon size={18} />, label: 'Dream' },
                 { id: 'facescan', icon: <Camera size={18} />, label: 'Face' },
                 { id: 'aura', icon: <Zap size={18} />, label: 'Aura' },
                 { id: 'shadow', icon: <Ghost size={18} />, label: 'Shadow' },
             ].map(tab => (
                 <button 
                   key={tab.id}
                   onClick={() => handleTabChange(tab.id as Tab)}
                   className={`flex items-center gap-2 px-4 py-3 rounded-xl transition-all ${activeTab === tab.id ? activeClass : inactiveClass}`}
                 >
                   {tab.icon}
                   <span className="font-medium hidden md:inline">{tab.label}</span>
                 </button>
             ))}
         </div>
      </div>

      <div className="min-h-[400px]">
         {activeTab === 'decoder' && <MessageDecoder />}
         {activeTab === 'dream' && <DreamInterpreter />}
         {activeTab === 'facescan' && <FaceScanner />}
         {activeTab === 'aura' && <AuraGenerator />}
         {activeTab === 'shadow' && <ShadowWork />}
      </div>
    </div>
  );
};

const ShadowWork: React.FC = () => {
    const { user, unlockCrystal } = useContext(UserContext);
    const isDark = user.theme === 'dark';
    const [struggle, setStruggle] = useState("");
    const [insight, setInsight] = useState("");
    const [loading, setLoading] = useState(false);

    const handleAnalyze = async () => {
        if(!struggle.trim()) return;
        setLoading(true);
        const archetype = user.archetype ? ARCHETYPES[user.archetype].name : "Seeker";
        const res = await analyzeShadowWork(archetype, struggle);
        setInsight(res);
        setLoading(false);
        unlockCrystal('obsidian');
    };

    const cardBg = isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm';
    const inputBg = isDark ? 'bg-black/20 border-white/5 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-900';

    return (
        <div className="max-w-2xl mx-auto">
             {!insight ? (
                 <div className={`p-8 rounded-[2rem] border space-y-6 ${cardBg}`}>
                     <div className={`flex items-center gap-2 mb-2 justify-center ${isDark ? 'text-stone-300' : 'text-stone-600'}`}>
                         <Ghost size={24} />
                         <h2 className="font-serif text-2xl">Shadow Work Journal</h2>
                     </div>
                     <p className="text-center text-stone-400 text-sm">Confront the hidden parts of yourself.</p>
                     
                     <textarea 
                        value={struggle}
                        onChange={(e) => setStruggle(e.target.value)}
                        placeholder="I am feeling resentful because..."
                        className={`w-full h-32 rounded-xl p-4 focus:border-stone-500 outline-none ${inputBg}`}
                     />
                     <button 
                        onClick={handleAnalyze}
                        disabled={loading || !struggle}
                        className={`w-full py-4 rounded-xl transition-colors font-semibold border ${isDark ? 'bg-stone-800 text-stone-200 border-white/5 hover:bg-stone-700' : 'bg-stone-900 text-white border-stone-900 hover:bg-stone-700'}`}
                     >
                         {loading ? "Confronting Shadow..." : "Illuminate"}
                     </button>
                 </div>
             ) : (
                 <div className="animate-fade-in-up space-y-6">
                     <div className={`p-8 rounded-[2rem] border relative overflow-hidden ${cardBg}`}>
                         <h3 className={`font-serif text-2xl mb-6 text-center ${isDark ? 'text-stone-200' : 'text-stone-800'}`}>Shadow Insight</h3>
                         <p className={`text-lg leading-relaxed italic text-center font-serif ${isDark ? 'text-stone-300' : 'text-stone-600'}`}>"{insight}"</p>
                     </div>
                     <button onClick={() => setInsight("")} className="w-full text-center text-stone-500 hover:text-stone-400">Journal again</button>
                 </div>
             )}
        </div>
    );
};

const AuraGenerator: React.FC = () => {
  const { user, unlockCrystal } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const [mood, setMood] = useState("");
  const [result, setResult] = useState<AuraResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!mood.trim()) return;
    setLoading(true);
    const archetype = user.archetype ? ARCHETYPES[user.archetype].name : "Seeker";
    const res = await getAuraReading(archetype, mood);
    setResult(res);
    setLoading(false);
    unlockCrystal('citrine');
  };

  const cardBg = isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm';
  const inputBg = isDark ? 'bg-black/20 border-white/5 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-900';

  return (
    <div className="max-w-2xl mx-auto">
      {!result ? (
        <div className={`space-y-6 p-8 rounded-[2rem] border text-center ${cardBg}`}>
           <div className="flex flex-col items-center gap-2 text-amber-400 mb-4">
              <Zap size={32} strokeWidth={1.5} />
              <h2 className={`font-serif text-2xl ${isDark ? 'text-stone-100' : 'text-stone-900'}`}>Discover Your Current Aura</h2>
           </div>
           <input 
             value={mood}
             onChange={(e) => setMood(e.target.value)}
             placeholder="I am feeling..."
             className={`w-full rounded-xl p-4 text-center text-lg focus:border-amber-500/50 outline-none ${inputBg}`}
           />
           <button 
             onClick={handleGenerate}
             disabled={loading || !mood.trim()}
             className="w-full py-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-medium rounded-xl transition-all disabled:opacity-50 hover:brightness-110"
           >
             {loading ? "Reading Energy Field..." : "Reveal My Aura"}
           </button>
        </div>
      ) : (
         <div className="space-y-8 animate-fade-in-up">
            <div className={`relative overflow-hidden rounded-[2rem] p-8 text-center border h-96 flex flex-col justify-center items-center shadow-2xl ${cardBg}`}>
                 <div className="absolute inset-0 opacity-40 transition-all duration-1000" style={{background: `radial-gradient(circle at center, ${result.colorCode} 0%, transparent 70%)`}}></div>
                 <div className="relative z-10">
                    <h3 className={`text-4xl font-serif mb-2 drop-shadow-lg tracking-wide ${isDark ? 'text-white' : 'text-stone-900'}`}>{result.colorName}</h3>
                    <p className={`text-xl font-light leading-relaxed italic drop-shadow-md max-w-lg mx-auto font-serif ${isDark ? 'text-stone-100' : 'text-stone-800'}`}>"{result.meaning}"</p>
                 </div>
            </div>
            <div className={`border p-6 rounded-2xl text-center ${cardBg}`}>
               <span className="text-xs uppercase tracking-widest text-amber-500 block mb-2">Weekly Prediction</span>
               <p className={isDark ? 'text-stone-300' : 'text-stone-600'}>{result.prediction}</p>
            </div>
            <button onClick={() => setResult(null)} className="text-stone-500 hover:text-stone-400 w-full text-center py-4">Check aura again</button>
         </div>
      )}
    </div>
  );
}

const MessageDecoder: React.FC = () => {
    const { user } = useContext(UserContext);
    const isDark = user.theme === 'dark';
    const [message, setMessage] = useState("");
    const [context, setContext] = useState("");
    const [result, setResult] = useState<MessageAnalysisResult | null>(null);
    const [loading, setLoading] = useState(false);
  
    const handleDecode = async () => {
      if (!message.trim()) return;
      setLoading(true);
      const res = await analyzeMessage(message, context);
      setResult(res);
      setLoading(false);
    };

    const cardBg = isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm';
    const inputBg = isDark ? 'bg-black/20 border-white/5 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-900';
  
    return (
      <div className="max-w-2xl mx-auto">
         {!result ? (
           <div className={`space-y-6 p-8 rounded-[2rem] border ${cardBg}`}>
              <div className={`flex items-center gap-3 mb-2 ${isDark ? 'text-stone-200' : 'text-stone-800'}`}>
                  <MessageCircle size={24} />
                  <h2 className="font-serif text-2xl">See What They Really Mean</h2>
              </div>
              <textarea 
                   value={message}
                   onChange={(e) => setMessage(e.target.value)}
                   placeholder="Paste the text here..."
                   className={`w-full rounded-xl p-4 focus:border-stone-500 outline-none min-h-[100px] ${inputBg}`}
                 />
                 <input 
                   value={context}
                   onChange={(e) => setContext(e.target.value)}
                   placeholder="Context (Optional)..."
                   className={`w-full rounded-xl p-4 focus:border-stone-500 outline-none ${inputBg}`}
                 />
              <button 
                onClick={handleDecode}
                disabled={loading || !message.trim()}
                className={`w-full py-4 font-medium rounded-xl transition-colors border disabled:opacity-50 ${isDark ? 'bg-stone-800 text-stone-200 border-white/10 hover:bg-stone-700' : 'bg-stone-900 text-white border-stone-900 hover:bg-stone-700'}`}
              >
                {loading ? "Decoding Subtext..." : "Decode Truth"}
              </button>
           </div>
         ) : (
           <div className="space-y-6 animate-fade-in-up">
              <div className={`p-6 rounded-2xl border flex items-center gap-4 ${result.redFlagRating === 'Danger' ? 'bg-red-500/10 border-red-500/20' : result.redFlagRating === 'Caution' ? 'bg-amber-500/10 border-amber-500/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
                  {result.redFlagRating === 'Danger' && <AlertTriangle className="text-red-500" size={32} />}
                  <div>
                     <p className="text-xs uppercase tracking-widest opacity-70">Safety Check</p>
                     <p className={`text-xl font-serif font-bold ${isDark ? 'text-white' : 'text-stone-900'}`}>{result.redFlagRating} Level</p>
                  </div>
              </div>
              <div className={`p-6 rounded-2xl border ${cardBg}`}>
                 <h3 className={`font-serif text-lg mb-2 ${isDark ? 'text-stone-300' : 'text-stone-700'}`}>Hidden Emotion</h3>
                 <p className={isDark ? 'text-stone-400' : 'text-stone-600'}>"{result.hiddenEmotion}"</p>
              </div>
              <div className={`p-8 rounded-2xl border text-center ${isDark ? 'bg-stone-800/50 border-white/5' : 'bg-stone-100 border-stone-200'}`}>
                 <h3 className={`font-serif text-xl mb-4 ${isDark ? 'text-stone-100' : 'text-stone-900'}`}>Advice From The Universe</h3>
                 <p className={`text-lg italic font-serif ${isDark ? 'text-stone-300' : 'text-stone-700'}`}>"{result.advice}"</p>
              </div>
              <button onClick={() => setResult(null)} className="text-stone-500 hover:text-stone-400 w-full text-center py-4">Analyze another message</button>
           </div>
         )}
      </div>
    );
}

const DreamInterpreter: React.FC = () => {
    const { user } = useContext(UserContext);
    const isDark = user.theme === 'dark';
    const [dream, setDream] = useState("");
    const [result, setResult] = useState<MessageAnalysisResult | null>(null);
    const [loading, setLoading] = useState(false);

    const handleAnalyze = async () => {
        if (!dream.trim()) return;
        setLoading(true);
        const res = await analyzeDream(dream);
        setResult(res);
        setLoading(false);
    };

    const cardBg = isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm';
    const inputBg = isDark ? 'bg-black/20 border-white/5 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-900';

    return (
      <div className="max-w-2xl mx-auto">
          {!result ? (
              <div className={`space-y-6 p-8 rounded-[2rem] border ${cardBg}`}>
                  <div className={`flex items-center gap-3 mb-2 ${isDark ? 'text-stone-200' : 'text-stone-800'}`}>
                      <Moon size={24} />
                      <h2 className="font-serif text-2xl">Dream Decoder</h2>
                  </div>
                  <p className="text-stone-500 text-sm">Dreams are letters from your subconscious.</p>
                  <textarea 
                      value={dream}
                      onChange={(e) => setDream(e.target.value)}
                      placeholder="I dreamt that..."
                      className={`w-full rounded-xl p-4 focus:border-stone-500 outline-none min-h-[120px] ${inputBg}`}
                  />
                  <button 
                      onClick={handleAnalyze}
                      disabled={loading || !dream.trim()}
                      className={`w-full py-4 font-medium rounded-xl transition-colors border disabled:opacity-50 ${isDark ? 'bg-stone-800 text-stone-200 border-white/10 hover:bg-stone-700' : 'bg-stone-900 text-white border-stone-900 hover:bg-stone-700'}`}
                  >
                      {loading ? "Reading Symbols..." : "Interpret Dream"}
                  </button>
              </div>
          ) : (
              <div className="space-y-6 animate-fade-in-up">
                   <div className={`p-8 rounded-[2rem] border ${cardBg}`}>
                      <h3 className={`font-serif text-xl mb-4 ${isDark ? 'text-stone-100' : 'text-stone-900'}`}>Symbolic Meaning</h3>
                      <p className={`text-lg leading-relaxed italic ${isDark ? 'text-stone-300' : 'text-stone-700'}`}>"{result.realMeaning}"</p>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div className={`p-6 rounded-xl border ${cardBg}`}>
                           <span className="text-xs uppercase tracking-widest text-stone-500 block mb-2">Hidden Emotion</span>
                           <p className={isDark ? 'text-stone-300' : 'text-stone-700'}>{result.hiddenEmotion}</p>
                       </div>
                       <div className={`p-6 rounded-xl border ${cardBg}`}>
                           <span className="text-xs uppercase tracking-widest text-rose-500 block mb-2">Guidance</span>
                           <p className={isDark ? 'text-stone-300' : 'text-stone-700'}>{result.advice}</p>
                       </div>
                   </div>
                   <button onClick={() => setResult(null)} className="text-stone-500 hover:text-stone-400 w-full text-center py-4">Interpret another dream</button>
              </div>
          )}
      </div>
    );
}

const FaceScanner: React.FC = () => {
    const { user, unlockCrystal } = useContext(UserContext);
    const isDark = user.theme === 'dark';
    const [image, setImage] = useState<string | null>(null);
    const [result, setResult] = useState<FaceScanResult | null>(null);
    const [loading, setLoading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
  
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImage(reader.result as string);
          setResult(null);
        };
        reader.readAsDataURL(file);
      }
    };
  
    const handleScan = async () => {
      if (!image) return;
      setLoading(true);
      try {
          const res = await analyzeFaceScan(image);
          setResult(res);
          unlockCrystal('obsidian');
      } catch (e) {
          console.error(e);
      }
      setLoading(false);
    };

    const triggerFile = () => {
        fileInputRef.current?.click();
    }

    const cardBg = isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm';
    const heading = isDark ? 'text-stone-100' : 'text-stone-900';
  
    return (
      <div className="max-w-2xl mx-auto">
          {!result ? (
             <div className={`p-8 rounded-[2rem] border space-y-8 ${cardBg}`}>
                <div className="text-center">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${isDark ? 'bg-stone-800' : 'bg-stone-100'}`}>
                       <ScanFace size={32} className={isDark ? 'text-rose-200' : 'text-rose-500'} />
                    </div>
                    <h2 className={`font-serif text-2xl mb-2 ${heading}`}>Soul Energy Scan</h2>
                    <p className="text-stone-500 text-sm max-w-xs mx-auto">Upload a selfie to analyze your micro-expressions, stress levels, and hidden emotions.</p>
                </div>

                {/* Improved Upload Area */}
                <div className="space-y-4">
                    <div 
                        onClick={triggerFile}
                        className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors h-64 relative overflow-hidden group ${isDark ? 'border-white/10 hover:border-rose-500/50 hover:bg-white/5' : 'border-stone-300 hover:border-rose-400 hover:bg-stone-50'}`}
                    >
                        {image ? (
                            <img src={image} alt="Preview" className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-40 transition-opacity" />
                        ) : (
                            <>
                            <Upload size={32} className="mb-4 text-stone-400" />
                            <span className="text-stone-500 font-medium">Tap to select photo</span>
                            </>
                        )}
                        {image && (
                            <div className="relative z-10 bg-black/50 px-4 py-2 rounded-full text-white text-xs font-medium backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                Change Photo
                            </div>
                        )}
                        <input 
                            type="file" 
                            ref={fileInputRef}
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageUpload}
                        />
                    </div>

                    <button 
                        onClick={triggerFile}
                        className={`w-full py-3 rounded-xl border font-medium transition-all ${isDark ? 'border-white/10 hover:bg-white/5 text-stone-300' : 'border-stone-300 hover:bg-stone-100 text-stone-600'}`}
                    >
                        Open Camera / Upload
                    </button>
                </div>

                {image && (
                    <button 
                        onClick={handleScan}
                        disabled={loading}
                        className={`w-full py-4 font-medium rounded-xl transition-all shadow-lg disabled:opacity-70 ${isDark ? 'bg-gradient-to-r from-rose-900 to-stone-800 text-white' : 'bg-stone-900 text-white'}`}
                    >
                        {loading ? "Scanning Soul Energy..." : "Reveal Hidden Emotion"}
                    </button>
                )}
             </div>
          ) : (
             <div className="animate-fade-in-up space-y-8">
                 <div className="flex items-center gap-6">
                     <div className="w-24 h-24 rounded-2xl overflow-hidden border border-white/10 shadow-lg shrink-0">
                         <img src={image!} alt="Scanned" className="w-full h-full object-cover" />
                     </div>
                     <div>
                         <span className="text-xs uppercase tracking-widest text-rose-400">Detected Vibe</span>
                         <h2 className={`text-3xl font-serif ${heading}`}>{result.vibe}</h2>
                     </div>
                 </div>

                 <div className={`p-8 rounded-[2rem] border relative overflow-hidden ${cardBg}`}>
                     <h3 className={`font-serif text-xl mb-2 text-center ${heading}`}>What You Are Hiding</h3>
                     <p className={`text-lg text-center italic leading-relaxed ${isDark ? 'text-stone-300' : 'text-stone-700'}`}>"{result.hiddenEmotion}"</p>
                     <div className="mt-6 pt-6 border-t border-dashed border-stone-500/20 text-center">
                        <p className="text-sm text-rose-400 font-medium">{result.soulMessage}</p>
                     </div>
                 </div>

                 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                     {[
                         { label: "Stress", val: result.stressLevel, color: "bg-rose-500" },
                         { label: "Fatigue", val: result.emotionalFatigue, color: "bg-indigo-500" },
                         { label: "Confidence", val: result.confidence, color: "bg-emerald-500" },
                     ].map((stat, i) => (
                         <div key={i} className={`p-4 rounded-2xl border text-center ${cardBg}`}>
                             <span className="text-xs uppercase text-stone-500">{stat.label}</span>
                             <div className={`text-2xl font-serif my-2 ${heading}`}>{stat.val}%</div>
                             <div className="h-1.5 bg-stone-200/20 rounded-full overflow-hidden">
                                 <div className={`h-full ${stat.color}`} style={{width: `${stat.val}%`}}></div>
                             </div>
                         </div>
                     ))}
                 </div>

                 <button 
                    onClick={() => setResult(null)} 
                    className="w-full flex items-center justify-center gap-2 py-4 text-stone-500 hover:text-rose-400 transition-colors"
                 >
                     <RefreshCcw size={16} /> Scan Another Photo
                 </button>
             </div>
          )}
      </div>
    );
}
