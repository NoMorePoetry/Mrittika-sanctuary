
import React, { useContext, useState, useEffect } from 'react';
import { UserContext } from '../context';
import { getDailyReflection, getSmartBarnumPrompt, getInnerChildInsight } from '../services/geminiService';
import { ARCHETYPES } from '../constants';
import { ShareCard } from './ShareCard';
import { Loader2, Sparkles, Heart, Zap, Moon, Shield, Eye, Feather, Star, Fingerprint, Baby } from 'lucide-react';
import { BARNUM_PROMPTS, BARNUM_CATEGORIES } from '../data/prompts';

export const DailyReflection: React.FC = () => {
  const { user } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const archetype = user.archetype ? ARCHETYPES[user.archetype] : ARCHETYPES.lunar_empath;
  const [reflection, setReflection] = useState("");
  const [smartEcho, setSmartEcho] = useState("");
  const [innerChildMsg, setInnerChildMsg] = useState("");
  const [loading, setLoading] = useState(true);
  
  // Oracle Deck State
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [oracleCard, setOracleCard] = useState<string | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const [dailyMsg, smartMsg, innerChild] = await Promise.all([
        getDailyReflection(archetype.name),
        getSmartBarnumPrompt(archetype.name, user.history.moods[user.history.moods.length - 1]?.result),
        getInnerChildInsight(archetype.name, user.history.moods[user.history.moods.length - 1]?.result.emotionalTone)
      ]);
      setReflection(dailyMsg);
      setSmartEcho(smartMsg);
      setInnerChildMsg(innerChild);
      setLoading(false);
    };
    load();
  }, [archetype.name]);

  const drawCard = (category: string) => {
    setIsFlipping(true);
    setSelectedCategory(category);
    setOracleCard(null);
    setTimeout(() => {
      const prompts = BARNUM_PROMPTS[category];
      const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
      setOracleCard(randomPrompt);
      setIsFlipping(false);
    }, 1500);
  };

  const CategoryIcon = ({ cat }: { cat: string }) => {
    switch (cat) {
      case BARNUM_CATEGORIES.RELATIONSHIPS: return <Heart size={20} />;
      case BARNUM_CATEGORIES.CRUSHES: return <Sparkles size={20} />;
      case BARNUM_CATEGORIES.EXES: return <Moon size={20} />;
      case BARNUM_CATEGORIES.SELF_LOVE: return <Star size={20} />;
      case BARNUM_CATEGORIES.HEALING: return <Feather size={20} />;
      case BARNUM_CATEGORIES.WOUNDS: return <Shield size={20} />;
      case BARNUM_CATEGORIES.PREDICTIONS: return <Eye size={20} />;
      default: return <Zap size={20} />;
    }
  };

  const formatCategory = (cat: string) => cat === BARNUM_CATEGORIES.EXES ? "Past Echoes" : cat.replace('_', ' ');

  const heading = isDark ? 'text-white' : 'text-stone-900';
  const subHeading = isDark ? 'text-stone-300' : 'text-stone-600';

  return (
    <div className="flex flex-col items-center min-h-[60vh] max-w-4xl mx-auto space-y-8 md:space-y-12 pb-12">
      
      {/* Guidance Section */}
      <div className="w-full max-w-2xl space-y-8">
        {loading ? (
          <div className="flex justify-center p-12">
             <Loader2 className="animate-spin text-indigo-400" size={40} />
          </div>
        ) : (
          <div className="animate-fade-in space-y-6 md:space-y-8">
            <div className="text-center px-4">
              <span className="text-xs font-bold text-indigo-400 tracking-widest uppercase mb-2 block">
                {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
              </span>
              <h2 className={`text-2xl md:text-3xl font-serif ${heading}`}>Cosmic Alignment</h2>
            </div>
            
            <div className="min-h-[320px]">
                <ShareCard 
                title="Today's Truth"
                content={reflection}
                subtext={`For the ${archetype.name}`}
                theme="purple"
                />
            </div>

            {/* Smart Echo */}
            <div className="relative mt-8 group mx-2 md:mx-0">
               <div className={`absolute inset-0 blur-xl opacity-40 transition-opacity ${isDark ? 'bg-gradient-to-r from-stone-800 to-stone-700' : 'bg-gradient-to-r from-stone-200 to-amber-100'}`}></div>
               <div className={`relative border rounded-[2rem] p-6 md:p-8 flex flex-col md:flex-row gap-6 items-center shadow-xl ${isDark ? 'bg-[#292524] border-white/10' : 'bg-white border-stone-200'}`}>
                   <div className={`p-4 rounded-full border shrink-0 ${isDark ? 'bg-stone-900 border-white/5' : 'bg-stone-100 border-stone-200'}`}>
                      <Fingerprint size={32} className="text-amber-400" strokeWidth={1.5} />
                   </div>
                   <div className="text-center md:text-left">
                       <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                          <h3 className={`font-serif text-lg md:text-xl ${isDark ? 'text-amber-100' : 'text-amber-900'}`}>Your Personal Echo</h3>
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 text-[10px] uppercase tracking-wider border border-amber-500/20">Smart Insight</span>
                       </div>
                       <p className={`leading-relaxed italic text-sm md:text-base ${subHeading}`}>"{smartEcho}"</p>
                   </div>
               </div>
            </div>

            {/* Inner Child */}
            <div className={`border rounded-[2rem] p-6 md:p-8 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-rose-900/20 to-stone-900/30 border-rose-500/10' : 'bg-gradient-to-br from-rose-50 to-white border-rose-100'}`}>
                <div className="flex items-center gap-3 mb-4">
                    <Baby className="text-rose-400" size={24} />
                    <h3 className={`font-serif text-xl ${isDark ? 'text-rose-100' : 'text-rose-900'}`}>Inner Child Whispers</h3>
                </div>
                <p className={`font-light italic text-lg leading-relaxed ${subHeading}`}>
                    "{innerChildMsg}"
                </p>
            </div>
          </div>
        )}
      </div>

      {/* Oracle Deck */}
      <div className={`w-full animate-slide-up border-t pt-8 md:pt-12 ${isDark ? 'border-white/10' : 'border-stone-200'}`}>
         <div className="text-center mb-6 md:mb-8 px-4">
            <h2 className="text-2xl md:text-3xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400">The Oracle Deck</h2>
            <p className={`mt-2 text-sm md:text-base ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>What does your soul need to hear right now? Pick a card.</p>
         </div>

         {!oracleCard && !isFlipping && (
           <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 animate-fade-in px-2">
              {Object.values(BARNUM_CATEGORIES).map((cat) => (
                <button
                  key={cat}
                  onClick={() => drawCard(cat)}
                  className={`group relative p-4 md:p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 flex flex-col items-center gap-3 active:scale-95 ${
                    isDark 
                    ? 'border-white/10 bg-slate-900/50 hover:bg-white/10 hover:border-purple-500/30' 
                    : 'border-stone-200 bg-white hover:bg-purple-50 hover:border-purple-300 shadow-sm'
                  }`}
                >
                   <div className={`p-3 rounded-full transition-colors ${isDark ? 'bg-white/5 text-purple-300 group-hover:bg-purple-500/20' : 'bg-purple-50 text-purple-600 group-hover:bg-purple-100'}`}>
                      <CategoryIcon cat={cat} />
                   </div>
                   <span className={`text-xs md:text-sm font-medium capitalize tracking-wide text-center leading-tight ${isDark ? 'text-slate-300 group-hover:text-white' : 'text-slate-600 group-hover:text-purple-900'}`}>
                       {formatCategory(cat)}
                   </span>
                </button>
              ))}
           </div>
         )}

         {isFlipping && (
            <div className="flex flex-col items-center justify-center py-16">
               <div className="w-40 h-60 md:w-48 md:h-72 bg-gradient-to-br from-purple-900 to-indigo-900 rounded-2xl border-2 border-white/20 shadow-[0_0_50px_rgba(139,92,246,0.3)] animate-[flip_1s_infinite_linear] relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                     <Sparkles className="text-white/50 animate-pulse" size={48} />
                  </div>
               </div>
               <p className="mt-8 text-purple-400 font-serif animate-pulse tracking-widest text-sm">Consulting the threads of fate...</p>
            </div>
         )}

         {oracleCard && !isFlipping && (
            <div className="max-w-xl mx-auto animate-scale-in relative group px-2">
               <div className="relative bg-slate-900 border border-white/20 p-1 rounded-[2rem] shadow-2xl">
                  <div className="bg-gradient-to-br from-slate-900 to-slate-950 rounded-[1.9rem] p-8 md:p-12 text-center relative overflow-hidden min-h-[300px] flex flex-col justify-center">
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500"></div>
                      
                      <span className="inline-block px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] uppercase tracking-[0.2em] text-purple-300 mb-6 mx-auto w-fit">
                         {selectedCategory ? formatCategory(selectedCategory) : ''} Insight
                      </span>
                      
                      <p className="text-lg md:text-2xl text-white font-serif leading-relaxed italic drop-shadow-lg mb-8">
                        "{oracleCard}"
                      </p>
                      
                      <div className="flex justify-center gap-4">
                         <button 
                           onClick={() => setOracleCard(null)}
                           className="text-slate-400 text-sm hover:text-white transition-colors flex items-center gap-2 px-4 py-2 rounded-full bg-white/5"
                         >
                            <Zap size={14} /> Draw Another
                         </button>
                      </div>
                  </div>
               </div>
            </div>
         )}
      </div>

      <style>{`
        @keyframes flip {
          0% { transform: rotateY(0deg); }
          50% { transform: rotateY(90deg); }
          100% { transform: rotateY(0deg); }
        }
        .animate-scale-in {
          animation: scaleIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
          opacity: 0;
          transform: scale(0.9);
        }
        @keyframes scaleIn {
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
};
