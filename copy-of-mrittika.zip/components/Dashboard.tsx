
import React, { useContext, useEffect, useState } from 'react';
import { UserContext } from '../context';
import { ARCHETYPES } from '../constants';
import { ShareCard } from './ShareCard';
import { getDailyReflection, getAuraReading, getDailyHoroscope } from '../services/geminiService';
import { Link } from 'react-router-dom';
import { ArrowRight, Eye, X, Zap, Activity, Heart, Flower, Star, Loader2 } from 'lucide-react';
import { AuraResult } from '../types';
import { PUSH_NOTIFICATIONS } from '../data/notifications';

export const Dashboard: React.FC = () => {
  const { user, unlockCrystal } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const archetype = user.archetype ? ARCHETYPES[user.archetype] : ARCHETYPES.lunar_empath;
  const [dailyMsg, setDailyMsg] = useState<string>("");
  const [aura, setAura] = useState<AuraResult | null>(null);
  const [horoscope, setHoroscope] = useState("");
  const [notification, setNotification] = useState<{title: string, body: string} | null>(null);
  const [moonPhase, setMoonPhase] = useState("Waxing Crescent");

  useEffect(() => {
    const loadDaily = async () => {
       getDailyReflection(archetype.name).then(setDailyMsg);
       unlockCrystal('rose_quartz');
       
       getAuraReading(archetype.name).then(res => {
           setAura(res);
           if(res) unlockCrystal('citrine');
       });

       if (user.zodiacSign) {
           getDailyHoroscope(archetype.name, user.zodiacSign).then(setHoroscope);
       }
    };
    loadDaily();

    const timer = setTimeout(() => {
      const randomNotif = PUSH_NOTIFICATIONS[Math.floor(Math.random() * PUSH_NOTIFICATIONS.length)];
      setNotification(randomNotif);
    }, 4000);
    
    const phases = ["New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous", "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent"];
    setMoonPhase(phases[Math.floor(Date.now() / (1000 * 60 * 60 * 24 * 3)) % 8]);

    return () => clearTimeout(timer);
  }, [archetype.name, user.zodiacSign]);

  const cardBg = isDark ? 'bg-[#292524] border-white/5' : 'bg-white border-stone-200 shadow-sm';
  const textMain = isDark ? 'text-stone-200' : 'text-stone-800';
  const textSub = isDark ? 'text-stone-400' : 'text-stone-500';
  const heading = isDark ? 'text-stone-100' : 'text-stone-900';

  return (
    <div className="space-y-6 md:space-y-8 animate-fade-in relative">
      {/* Background Orbs */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <div className={`absolute top-[-10%] left-[-10%] w-[40rem] h-[40rem] rounded-full mix-blend-screen filter blur-[100px] opacity-20 animate-[pulse_10s_ease-in-out_infinite] ${isDark ? 'bg-rose-900/30' : 'bg-rose-200'}`}></div>
        <div className={`absolute top-[30%] right-[-10%] w-[30rem] h-[30rem] rounded-full mix-blend-screen filter blur-[80px] opacity-15 animate-[pulse_15s_ease-in-out_infinite] delay-1000 ${isDark ? 'bg-indigo-900/30' : 'bg-indigo-200'}`}></div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className="fixed top-4 right-4 md:right-8 z-50 animate-slide-in-right max-w-[90vw] md:max-w-sm w-full">
           <div className={`p-4 rounded-2xl shadow-2xl flex items-start gap-4 relative overflow-hidden ${isDark ? 'bg-[#1c1917]/90 border border-white/5' : 'bg-white/90 border border-stone-200'}`}>
              <div className="absolute top-0 left-0 w-1 h-full bg-rose-500"></div>
              <div className={`p-2 rounded-lg shrink-0 ${isDark ? 'bg-white/5' : 'bg-stone-100'}`}>
                 <Heart size={20} className="text-rose-400" />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="flex justify-between items-start">
                    <h4 className={`text-sm font-bold mb-1 ${heading}`}>Mrittika</h4>
                    <span className="text-xs text-stone-500">now</span>
                 </div>
                 <p className={`text-sm font-semibold mb-0.5 truncate ${textMain}`}>{notification.title}</p>
                 <p className={`text-xs leading-relaxed line-clamp-2 ${textSub}`}>{notification.body}</p>
              </div>
              <button onClick={() => setNotification(null)} className="text-stone-400 hover:text-stone-600 shrink-0">
                 <X size={14} />
              </button>
           </div>
        </div>
      )}

      {/* Compact Header Area */}
      <div className="flex flex-row justify-between items-center pt-2 pb-2">
         <div className="flex items-center gap-3 md:hidden">
            <div className="w-10 h-10 flex items-center justify-center bg-gradient-to-br from-stone-700 to-stone-900 rounded-xl shadow-lg border border-white/10 shrink-0">
                <Flower className="text-rose-200/90" size={20} strokeWidth={1.5} />
            </div>
            <span className={`font-serif text-lg tracking-widest ${heading}`}>MRITTIKA</span>
         </div>
         
         <div className={`ml-auto px-4 py-2 rounded-full flex items-center gap-3 border backdrop-blur-sm ${cardBg}`}>
             <div className={`w-6 h-6 rounded-full border shadow-inner relative overflow-hidden ${isDark ? 'bg-stone-900 border-white/10' : 'bg-stone-200 border-stone-300'}`}>
                 <div className={`absolute inset-0 rounded-full translate-x-1/3 ${isDark ? 'bg-stone-700' : 'bg-stone-400'}`}></div> 
                 <div className={`absolute inset-0 rounded-full translate-x-1/2 ${isDark ? 'bg-stone-900' : 'bg-stone-200'}`}></div>
             </div>
             <span className={`text-xs uppercase tracking-wider ${textSub}`}>{moonPhase}</span>
         </div>
      </div>

      {/* Main Archetype Card with Welcome Integrated */}
      <div className={`p-6 md:p-10 rounded-[2rem] relative overflow-hidden shadow-2xl group ${archetype.colors[0]}`}>
         <div className="absolute inset-0 mix-blend-soft-light opacity-40 pointer-events-none">
             <div className="absolute -top-24 -left-24 w-64 h-64 md:w-96 md:h-96 bg-rose-900/40 rounded-full blur-[100px] animate-[float_12s_ease-in-out_infinite]"></div>
             <div className="absolute bottom-0 right-0 w-48 h-48 md:w-80 md:h-80 bg-amber-900/30 rounded-full blur-[80px] animate-[float_10s_ease-in-out_infinite_reverse]"></div>
         </div>
         
         <div className="relative z-10">
           <div className="mb-6">
               <p className="text-white/60 font-serif italic text-sm md:text-base mb-1">Welcome back, {user.name}</p>
               <h2 className={`text-4xl md:text-6xl font-serif ${archetype.colors[1]} drop-shadow-lg`}>{archetype.name}</h2>
           </div>
           
           <p className="text-stone-200 text-base md:text-xl leading-relaxed max-w-2xl mb-8 font-light font-serif drop-shadow-md">
             {archetype.description}
           </p>
           
           <div className="flex flex-col sm:flex-row gap-4">
             <Link to="/profile" className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-white text-stone-900 font-serif font-semibold hover:bg-stone-100 transition-all shadow-lg hover:-translate-y-0.5 text-sm md:text-base">
               Read Full Profile <ArrowRight size={16} />
             </Link>
             <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0">
                {archetype.strengths.map(s => (
                <span key={s} className="whitespace-nowrap px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-xs md:text-sm text-white/90 backdrop-blur-md cursor-default">
                    {s}
                </span>
                ))}
             </div>
           </div>
         </div>
      </div>
      
      {/* Stellar Guidance (Horoscope) */}
      {user.zodiacSign && (
          <div className={`relative rounded-[2rem] p-6 md:p-8 border overflow-hidden shadow-lg group ${isDark ? 'bg-[#1f1c1a] border-white/10' : 'bg-white border-stone-200'}`}>
              <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl group-hover:bg-purple-500/10 transition-colors"></div>
              <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400"><Star size={20} /></div>
                          <h3 className={`font-serif text-xl ${heading}`}>Stellar Guidance</h3>
                      </div>
                      <span className="text-xs font-bold uppercase tracking-widest text-purple-400 border border-purple-500/20 px-2 py-1 rounded-lg">{user.zodiacSign}</span>
                  </div>
                  {horoscope ? (
                      <p className={`font-light italic text-lg leading-relaxed ${textMain}`}>"{horoscope}"</p>
                  ) : (
                      <div className="flex items-center gap-2 text-sm text-stone-500"><Loader2 className="animate-spin" size={14} /> Aligning stars...</div>
                  )}
              </div>
          </div>
      )}

      {/* Grid: Aura & Heart */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
         <div className={`relative rounded-3xl overflow-hidden border group min-h-[280px] ${isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200 shadow-sm'}`}>
            {aura ? (
              <>
                <div className="absolute inset-0 opacity-30 transition-all duration-1000 group-hover:opacity-50"
                     style={{background: `radial-gradient(circle at center, ${aura.colorCode} 0%, transparent 70%)`}}></div>
                <div className="relative z-10 p-6 md:p-8 flex flex-col h-full">
                    <div className={`flex items-center gap-2 mb-4 ${textSub}`}>
                       <Zap size={18} />
                       <span className="text-xs uppercase tracking-widest">Your Aura Today</span>
                    </div>
                    <h3 className={`text-2xl md:text-3xl font-serif mb-2 ${heading}`}>{aura.colorName}</h3>
                    <p className={`leading-relaxed font-light mb-6 flex-grow font-serif italic text-sm md:text-base ${textMain}`}>"{aura.meaning}"</p>
                    <div className={`mt-auto p-4 rounded-xl backdrop-blur-md border ${isDark ? 'bg-white/5 border-white/5' : 'bg-stone-50 border-stone-100'}`}>
                       <span className="text-[10px] uppercase text-stone-500 block mb-1">Prediction</span>
                       <p className={`text-sm italic ${textMain}`}>{aura.prediction}</p>
                    </div>
                </div>
              </>
            ) : (
              <div className="h-full animate-pulse flex items-center justify-center text-stone-500 p-8">Reading Aura...</div>
            )}
         </div>

         <div className={`rounded-3xl p-6 md:p-8 border flex flex-col justify-center ${cardBg}`}>
             <div className="flex items-center gap-2 mb-6 text-rose-400">
                <Activity size={20} />
                <h3 className="font-serif text-xl">Heart Energy</h3>
             </div>
             <div className="space-y-6">
                <div>
                   <div className="flex justify-between text-sm text-stone-500 mb-2">
                      <span>Romantic Openness</span>
                      <span className="text-rose-400 font-medium">82%</span>
                   </div>
                   <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-black/20' : 'bg-stone-200'}`}>
                      <div className="h-full bg-rose-400 w-[82%]"></div>
                   </div>
                </div>
                <div>
                   <div className="flex justify-between text-sm text-stone-500 mb-2">
                      <span>Intuition Clarity</span>
                      <span className="text-amber-400 font-medium">95%</span>
                   </div>
                   <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-black/20' : 'bg-stone-200'}`}>
                      <div className="h-full bg-amber-400 w-[95%]"></div>
                   </div>
                </div>
             </div>
             <div className={`mt-6 pt-6 border-t ${isDark ? 'border-white/5' : 'border-stone-100'}`}>
                <p className={`text-sm text-center italic ${textSub}`}>
                   "Your calmness is magnetic today. Someone is quietly admiring your strength."
                </p>
             </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <div className="min-h-[300px]">
            <ShareCard title="Daily Insight" content={dailyMsg || "Aligning with the cosmos..."} subtext="Mrittika Reflection" theme="clay" />
        </div>
        <div className="space-y-3 md:space-y-4">
           {[
             { to: '/lab', icon: <Eye size={20} />, title: "Inner Lab", desc: "Decode messages, shadow work, face scans." },
             { to: '/mood', icon: null, title: "Mood Mirror", desc: "Vent your feelings and uncover hidden truths." },
             { to: '/relationships', icon: null, title: "Heart Insight", desc: "Understand connection style & compatibility." }
           ].map((item, i) => (
             <Link key={i} to={item.to} className={`block p-5 md:p-6 rounded-3xl border transition-all group relative overflow-hidden ${isDark ? 'bg-[#292524] border-white/5 hover:bg-[#35302e]' : 'bg-white border-stone-200 hover:bg-stone-50 shadow-sm'}`}>
                <div className="flex justify-between items-center mb-2 relative z-10">
                  <div className="flex items-center gap-3">
                      {item.icon && <div className={`p-2 rounded-lg ${isDark ? 'bg-stone-700/30 text-stone-200' : 'bg-stone-100 text-stone-600'}`}>{item.icon}</div>}
                      <h3 className={`font-serif text-lg md:text-xl transition-colors ${heading}`}>{item.title}</h3>
                  </div>
                  <ArrowRight className="text-stone-400 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
                <p className={`text-xs md:text-sm relative z-10 leading-relaxed mt-2 ${textSub}`}>{item.desc}</p>
             </Link>
           ))}
        </div>
      </div>
    </div>
  );
};
