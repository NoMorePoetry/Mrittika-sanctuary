import React, { useEffect, useRef, useState } from 'react';

export const GlobalAudio: React.FC = () => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [hasInteracted, setHasInteracted] = useState(false);

  // Permanent Archive.org Link (Wind Chimes) – verified working MP3
  // Ambientbytes 1.0 – "01-Wind Chimes.mp3"
  const AUDIO_SRC = "https://archive.org/download/ambientbytes1/01-Wind%20Chimes.mp3";

  useEffect(() => {
    const playIntro = async () => {
      const audio = audioRef.current;
      if (audio && !hasInteracted) {
        try {
          // Start Very Quiet (5%)
          audio.volume = 0.05;

          const playPromise = audio.play();
          if (playPromise !== undefined) {
            playPromise
              .then(() => {
                setHasInteracted(true);

                // Gentle Fade In
                let vol = 0.05;
                const fadeIn = setInterval(() => {
                  if (audio && vol < 0.2) {
                    vol += 0.01;
                    audio.volume = vol;
                  } else {
                    clearInterval(fadeIn);
                  }
                }, 100);

                // Fade out after 6 seconds
                setTimeout(() => {
                  const a = audioRef.current;
                  if (!a) return;

                  const fadeOut = setInterval(() => {
                    if (a && a.volume > 0.01) {
                      a.volume -= 0.01;
                    } else {
                      if (a) {
                        a.pause();
                        a.volume = 0;
                      }
                      clearInterval(fadeOut);
                    }
                  }, 100);
                }, 6000);
              })
              .catch(() => {
                // Silent fail if browser blocks auto-play
              });
          }
        } catch {
          // Ignore
        }
      }
    };

    const handleInteraction = () => {
      playIntro();
    };

    window.addEventListener('click', handleInteraction, { capture: true, once: true });
    window.addEventListener('touchstart', handleInteraction, { capture: true, once: true });

    return () => {
      window.removeEventListener('click', handleInteraction, { capture: true });
      window.removeEventListener('touchstart', handleInteraction, { capture: true });
    };
  }, [hasInteracted]);

  return <audio ref={audioRef} src={AUDIO_SRC} preload="auto" />;
};
