
import React, { useContext, useState } from 'react';
import { UserContext } from '../context';
import { History as HistoryIcon, ChevronDown, Quote, Sparkles, Calendar } from 'lucide-react';

export const History: React.FC = () => {
  const { user } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const toggleExpand = (idx: number) => {
    setExpandedIndex(expandedIndex === idx ? null : idx);
  };

  // Create a copy to reverse without mutating the original array
  const reversedHistory = [...user.history.moods].reverse();

  return (
    <div className="animate-fade-in max-w-3xl mx-auto pb-24">
      {/* Header */}
      <div className="text-center mb-16">
        <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-6 border backdrop-blur-md ${isDark ? 'bg-purple-500/10 border-purple-500/20 shadow-[0_0_30px_rgba(168,85,247,0.15)]' : 'bg-purple-50 border-purple-100 shadow-sm'}`}>
          <HistoryIcon className="text-purple-400" size={32} strokeWidth={1.5} />
        </div>
        <h2 className={`text-3xl font-serif tracking-wide mb-2 ${isDark ? 'text-stone-100' : 'text-stone-900'}`}>Your Constellation</h2>
        <p className={`text-sm font-light ${isDark ? 'text-stone-400' : 'text-stone-500'}`}>Connecting the dots of your emotional journey.</p>
      </div>

      <div className="relative px-4 md:px-0">
         {/* Central Timeline Line */}
         <div className={`absolute left-8 md:left-1/2 top-4 bottom-0 w-px -translate-x-1/2 ${isDark ? 'bg-gradient-to-b from-purple-500/50 via-purple-500/20 to-transparent' : 'bg-gradient-to-b from-purple-300 via-purple-200 to-transparent'}`}></div>

        {reversedHistory.length === 0 ? (
          <div className={`text-center p-12 rounded-[2rem] border mx-auto max-w-md relative z-10 ${isDark ? 'bg-[#1c1917] border-white/10' : 'bg-white border-stone-200'}`}>
            <Sparkles className="mx-auto text-stone-600 mb-4 opacity-50" size={24} />
            <p className={`font-serif italic ${isDark ? 'text-stone-500' : 'text-stone-400'}`}>The stars are waiting for your first entry...</p>
          </div>
        ) : (
          reversedHistory.map((entry, idx) => {
            const isExpanded = expandedIndex === idx;
            const date = new Date(entry.date);
            
            return (
            <div key={idx} className={`relative mb-12 flex flex-col md:flex-row ${idx % 2 === 0 ? 'md:flex-row-reverse' : ''} items-start md:items-center group`}>
              
              {/* Timeline Node */}
              <div className={`absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full border-2 z-20 transition-all duration-500 group-hover:scale-125 shadow-[0_0_15px_rgba(168,85,247,0.6)] ${isDark ? 'border-[#1c1917] bg-purple-500' : 'border-white bg-purple-400'}`}></div>
              
              {/* Date Label (Desktop: Opposite side) */}
              <div className={`hidden md:block w-1/2 px-12 ${idx % 2 === 0 ? 'text-left' : 'text-right'}`}>
                 <span className={`text-xs font-bold tracking-[0.2em] uppercase opacity-60 ${isDark ? 'text-stone-400' : 'text-stone-500'}`}>
                    {date.toLocaleDateString(undefined, { month: 'long', day: 'numeric' })}
                 </span>
              </div>

              {/* Content Card */}
              <div className={`w-full md:w-1/2 pl-20 md:pl-0 ${idx % 2 === 0 ? 'md:pr-12' : 'md:pl-12'}`}>
                  <button 
                    onClick={() => toggleExpand(idx)}
                    className={`w-full text-left transition-all duration-500 relative overflow-hidden group/card ${
                        isExpanded 
                        ? `rounded-[2rem] p-8 border ${isDark ? 'bg-slate-900/80 border-purple-500/30' : 'bg-white border-purple-200 shadow-lg'}` 
                        : `rounded-3xl p-6 border ${isDark ? 'bg-[#292524] border-white/5 hover:border-white/10' : 'bg-white border-stone-200 hover:border-purple-200 shadow-sm'}`
                    }`}
                  >
                    {/* Mobile Date (Visible only on small screens) */}
                    <div className="md:hidden mb-2 text-[10px] font-bold tracking-widest uppercase text-purple-400 opacity-80">
                        {date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} • {date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                    </div>

                    <div className="flex justify-between items-center">
                        <div>
                            <h3 className={`font-serif text-xl transition-colors ${isExpanded ? 'text-purple-300' : isDark ? 'text-stone-200' : 'text-stone-800'}`}>
                                {entry.result.emotionalTone}
                            </h3>
                            {!isExpanded && (
                                <p className={`text-xs mt-1 truncate max-w-[200px] ${isDark ? 'text-stone-500' : 'text-stone-400'}`}>
                                    Tap to expand...
                                </p>
                            )}
                        </div>
                        <div className={`p-2 rounded-full transition-transform duration-500 ${isExpanded ? 'rotate-180 bg-purple-500/10 text-purple-400' : 'text-stone-500'}`}>
                            <ChevronDown size={18} />
                        </div>
                    </div>

                    {/* Expanded Content */}
                    <div className={`grid transition-all duration-500 ease-in-out ${isExpanded ? 'grid-rows-[1fr] opacity-100 mt-6' : 'grid-rows-[0fr] opacity-0 mt-0'}`}>
                        <div className="overflow-hidden">
                            <div className="relative pl-6 border-l-2 border-purple-500/20">
                                <Quote className="absolute -left-2.5 -top-3 bg-transparent text-purple-500/40 p-0.5" size={20} fill="currentColor" />
                                <p className={`font-serif italic leading-relaxed ${isDark ? 'text-stone-300' : 'text-stone-600'}`}>
                                    "{entry.result.validatingStatement}"
                                </p>
                            </div>
                            
                            <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-dashed border-white/5">
                                <div className={`px-3 py-1.5 rounded-lg text-xs font-medium ${isDark ? 'bg-rose-500/10 text-rose-300' : 'bg-rose-50 text-rose-600'}`}>
                                    Need: {entry.result.keyDesire}
                                </div>
                                <div className={`px-3 py-1.5 rounded-lg text-xs font-medium ${isDark ? 'bg-indigo-500/10 text-indigo-300' : 'bg-indigo-50 text-indigo-600'}`}>
                                    Fear: {entry.result.hiddenFear}
                                </div>
                            </div>
                        </div>
                    </div>
                  </button>
              </div>
            </div>
          )})
        )}
      </div>
    </div>
  );
};
