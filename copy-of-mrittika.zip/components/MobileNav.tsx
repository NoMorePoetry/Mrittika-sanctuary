
import React, { useState, useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Moon, Heart, Sparkles, FlaskConical, Menu, X, Music, User, History, Sun, Settings } from 'lucide-react';
import { UserContext } from '../context';

export const MobileNav: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, updateUser, toggleSettings } = useContext(UserContext);
  const isDark = user.theme === 'dark';

  const toggleTheme = () => {
    updateUser({ theme: isDark ? 'light' : 'dark' });
    setIsMenuOpen(false);
  };

  const handleSettings = () => {
      setIsMenuOpen(false);
      toggleSettings();
  }

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex flex-col items-center justify-center gap-1 p-2 rounded-2xl transition-all duration-300 relative w-full h-full ${
      isActive 
        ? 'text-rose-200 bg-white/15 shadow-[0_0_15px_rgba(253,164,175,0.2)] scale-105' 
        : 'text-stone-400 hover:text-stone-200 opacity-80'
    }`;

  const menuLinkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-4 p-4 rounded-xl transition-all duration-300 border border-transparent ${
      isActive 
        ? 'bg-white/10 text-rose-100 border-rose-500/20' 
        : 'text-stone-300 hover:bg-white/5'
    }`;

  return (
    <>
      {/* Overlay Menu */}
      {isMenuOpen && (
        <>
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9998]" onClick={() => setIsMenuOpen(false)}></div>
            <div className="fixed bottom-24 right-4 left-4 bg-[#292524]/95 backdrop-blur-2xl border border-white/10 rounded-[2rem] p-4 shadow-2xl z-[9999] animate-fade-in-up origin-bottom max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-1 gap-2">
                    <button onClick={toggleTheme} className="flex items-center gap-4 p-4 rounded-xl transition-all text-stone-300 hover:bg-white/5 w-full text-left">
                        <div className="p-2 bg-stone-500/10 rounded-full text-stone-300">{isDark ? <Sun size={20} /> : <Moon size={20} />}</div>
                        <span className="font-serif tracking-wide">{isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}</span>
                    </button>
                    
                    <button onClick={handleSettings} className="flex items-center gap-4 p-4 rounded-xl transition-all text-stone-300 hover:bg-white/5 w-full text-left">
                        <div className="p-2 bg-stone-500/10 rounded-full text-stone-300"><Settings size={20} /></div>
                        <span className="font-serif tracking-wide">API Settings</span>
                    </button>

                    <div className="h-px bg-white/10 my-1"></div>

                    <NavLink to="/mood" className={menuLinkClass} onClick={() => setIsMenuOpen(false)}>
                        <div className="p-2 bg-purple-500/10 rounded-full text-purple-300"><Moon size={20} /></div>
                        <span className="font-serif tracking-wide">Mood Mirror</span>
                    </NavLink>
                    <NavLink to="/sanctuary" className={menuLinkClass} onClick={() => setIsMenuOpen(false)}>
                        <div className="p-2 bg-indigo-500/10 rounded-full text-indigo-300"><Music size={20} /></div>
                        <span className="font-serif tracking-wide">Soundscapes</span>
                    </NavLink>
                    <NavLink to="/profile" className={menuLinkClass} onClick={() => setIsMenuOpen(false)}>
                         <div className="p-2 bg-amber-500/10 rounded-full text-amber-300"><User size={20} /></div>
                        <span className="font-serif tracking-wide">My Archetype</span>
                    </NavLink>
                    <NavLink to="/history" className={menuLinkClass} onClick={() => setIsMenuOpen(false)}>
                        <div className="p-2 bg-emerald-500/10 rounded-full text-emerald-300"><History size={20} /></div>
                        <span className="font-serif tracking-wide">Journey</span>
                    </NavLink>
                </div>
            </div>
        </>
      )}

      {/* Main Bottom Bar */}
      <nav className="fixed bottom-0 left-0 w-full bg-[#1c1917]/95 backdrop-blur-2xl border-t border-white/10 z-[9999] md:hidden pb-safe shadow-[0_-10px_40px_rgba(0,0,0,0.9)]">
        <div className="flex justify-between items-center px-4 py-3 max-w-md mx-auto">
          <div className="flex-1 flex justify-center">
              <NavLink to="/dashboard" className={linkClass} onClick={() => setIsMenuOpen(false)}>
                <Home size={22} strokeWidth={1.5} />
                <span className="text-[9px] font-medium tracking-wide uppercase mt-1">Home</span>
              </NavLink>
          </div>
          <div className="flex-1 flex justify-center">
              <NavLink to="/daily" className={linkClass} onClick={() => setIsMenuOpen(false)}>
                <Sparkles size={22} strokeWidth={1.5} />
                <span className="text-[9px] font-medium tracking-wide uppercase mt-1">Daily</span>
              </NavLink>
          </div>
          <div className="flex-1 flex justify-center">
              <NavLink to="/lab" className={linkClass} onClick={() => setIsMenuOpen(false)}>
                <FlaskConical size={22} strokeWidth={1.5} />
                <span className="text-[9px] font-medium tracking-wide uppercase mt-1">Lab</span>
              </NavLink>
          </div>
          <div className="flex-1 flex justify-center">
              <NavLink to="/relationships" className={linkClass} onClick={() => setIsMenuOpen(false)}>
                <Heart size={22} strokeWidth={1.5} />
                <span className="text-[9px] font-medium tracking-wide uppercase mt-1">Heart</span>
              </NavLink>
          </div>
          <div className="flex-1 flex justify-center">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`flex flex-col items-center justify-center gap-1 p-2 rounded-2xl transition-all duration-300 relative w-full h-full ${isMenuOpen ? 'text-rose-200 bg-white/10' : 'text-stone-400'}`}
              >
                {isMenuOpen ? <X size={22} strokeWidth={1.5} /> : <Menu size={22} strokeWidth={1.5} />}
                <span className="text-[9px] font-medium tracking-wide uppercase mt-1">{isMenuOpen ? 'Close' : 'More'}</span>
              </button>
          </div>
        </div>
        <style>{`
          .pb-safe { padding-bottom: env(safe-area-inset-bottom, 16px); }
          @keyframes fade-in-up { from { opacity: 0; transform: translateY(20px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
          .animate-fade-in-up { animation: fade-in-up 0.2s ease-out forwards; }
        `}</style>
      </nav>
    </>
  );
};
