import React, { useState, useContext } from 'react';
import { UserContext } from '../context';
import { analyzeMood } from '../services/geminiService';
import { MoodAnalysisResult } from '../types';
import { ShareCard } from './ShareCard';
import { Loader2, Send } from 'lucide-react';
import { ARCHETYPES } from '../constants';

export const MoodAnalyzer: React.FC = () => {
  const { user, updateUser } = useContext(UserContext);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MoodAnalysisResult | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setLoading(true);
    setResult(null);

    const archetype = user.archetype ? ARCHETYPES[user.archetype].name : "Seeker";
    const analysis = await analyzeMood(input, archetype);
    
    setResult(analysis);
    setLoading(false);
    setInput("");

    // Optional: Save to history
    updateUser({
      history: {
        moods: [...user.history.moods, { date: new Date().toISOString(), result: analysis }]
      }
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-purple-200 to-indigo-200">
          Emotional Mirror
        </h2>
        <p className="text-slate-400">Pour your heart out. We will listen to what lies beneath.</p>
      </div>

      {!result && (
        <form onSubmit={handleAnalyze} className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="How are you feeling right now? Don't hold back..."
            className="w-full h-48 bg-white/5 border border-white/10 rounded-2xl p-6 text-lg text-slate-200 focus:outline-none focus:border-purple-500/50 resize-none placeholder:text-slate-600"
          />
          <div className="absolute bottom-4 right-4">
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-purple-600 hover:bg-purple-500 text-white rounded-full p-3 shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="animate-spin" size={24} /> : <Send size={24} />}
            </button>
          </div>
        </form>
      )}

      {loading && (
        <div className="text-center py-12 space-y-4">
          <p className="text-purple-300 animate-pulse font-serif italic text-xl">
            "Listening to the silence between your words..."
          </p>
        </div>
      )}

      {result && (
        <div className="space-y-6 animate-slide-up">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/50 border border-white/10 text-center">
                 <span className="text-xs uppercase text-slate-500 tracking-widest">Emotional Tone</span>
                 <p className="text-lg text-purple-200 font-serif mt-1">{result.emotionalTone}</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-900/50 border border-white/10 text-center">
                 <span className="text-xs uppercase text-slate-500 tracking-widest">Hidden Desire</span>
                 <p className="text-lg text-pink-200 font-serif mt-1">{result.keyDesire}</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-900/50 border border-white/10 text-center">
                 <span className="text-xs uppercase text-slate-500 tracking-widest">Subconscious Fear</span>
                 <p className="text-lg text-indigo-200 font-serif mt-1">{result.hiddenFear}</p>
              </div>
           </div>

           <ShareCard 
             title="Soul Reflection"
             content={result.validatingStatement}
             subtext={`Analysis for ${user.name}`}
             theme="rose"
           />
           
           <button 
             onClick={() => setResult(null)}
             className="w-full py-4 text-slate-400 hover:text-white transition-colors"
           >
             Analyze another feeling
           </button>
        </div>
      )}
    </div>
  );
};
