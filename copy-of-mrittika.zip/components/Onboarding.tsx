
import React, { useState, useContext } from 'react';
import { UserContext } from '../context';
import { ArchetypeId } from '../types';
import { useNavigate } from 'react-router-dom';
import { Moon, Sun, Sparkles, Heart, Sunrise } from 'lucide-react';
import { ARCHETYPES, ZODIAC_SIGNS } from '../constants';

const OnboardingLogo = ({isDark}: {isDark: boolean}) => (
  <div className="flex flex-col items-center gap-3 opacity-80 mb-8 animate-fade-in">
     <div className="relative">
        <Sunrise size={32} className="text-rose-400" strokeWidth={1.5} />
        <div className="absolute inset-0 bg-rose-500/20 blur-xl"></div>
     </div>
     <span className={`text-xl font-serif tracking-[0.2em] ${isDark ? 'text-rose-100' : 'text-stone-800'}`}>MRITTIKA</span>
  </div>
);

const questions = [
  {
    id: 1,
    text: "When the world feels too loud, where does your soul go?",
    options: [
      { text: "I retreat into deep silence and stillness.", type: ArchetypeId.LUNAR_EMPATH },
      { text: "I try to create order and fix the chaos.", type: ArchetypeId.QUIET_FLAME },
      { text: "I escape into my imagination and dreams.", type: ArchetypeId.STARLIT_WEAVER },
      { text: "I ground myself in the comfort of my home.", type: ArchetypeId.VELVET_ANCHOR },
    ]
  },
  {
    id: 2,
    text: "How do you show love to those closest to you?",
    options: [
      { text: "By telling them the hard truths they need to hear.", type: ArchetypeId.CRYSTAL_MIRROR },
      { text: "By listening without judgment or interruption.", type: ArchetypeId.OCEANIC_SAGE },
      { text: "By being their steady calm in the storm.", type: ArchetypeId.GENTLE_STORM },
      { text: "By encouraging them to be their wildest selves.", type: ArchetypeId.HIDDEN_WILDFLOWER },
    ]
  },
  {
    id: 3,
    text: "What is the hunger that drives you?",
    options: [
      { text: "To be truly understood without explaining.", type: ArchetypeId.LUNAR_EMPATH },
      { text: "To bloom authentically, without rules.", type: ArchetypeId.HIDDEN_WILDFLOWER },
      { text: "To build something lasting and safe.", type: ArchetypeId.VELVET_ANCHOR },
      { text: "To be recognized for my quiet strength.", type: ArchetypeId.QUIET_FLAME },
    ]
  }
];

export const Onboarding: React.FC = () => {
  const { updateUser, user } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const navigate = useNavigate();
  const [step, setStep] = useState(0); 
  const [name, setName] = useState("");
  const [zodiac, setZodiac] = useState("");
  const [scores, setScores] = useState<Record<string, number>>({});
  const [showReveal, setShowReveal] = useState(false);
  const [finalArchetype, setFinalArchetype] = useState<ArchetypeId | null>(null);

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
        setStep(0.2); 
    }
  };

  const handleZodiacSelect = (sign: string) => {
      setZodiac(sign);
      setStep(0.5); // Move to Welcome
      setTimeout(() => setStep(1), 3500);
  };

  const handleAnswer = (type: ArchetypeId) => {
    setScores(prev => ({ ...prev, [type]: (prev[type] || 0) + 1 }));
    if (step < questions.length) {
      setStep(prev => prev + 1);
    }
  };

  const finishQuiz = () => {
    const sorted = Object.entries(scores).sort((a, b) => (b[1] as number) - (a[1] as number));
    const result = sorted.length > 0 ? sorted[0][0] as ArchetypeId : ArchetypeId.LUNAR_EMPATH;
    setFinalArchetype(result);
    updateUser({ name, zodiacSign: zodiac, archetype: result, isPremium: true });
    setShowReveal(true);
  };

  const cardBg = isDark ? 'bg-white/5 border-white/5' : 'bg-white border-stone-200 shadow-xl';
  const textHeading = isDark ? 'text-stone-100' : 'text-stone-900';
  const textBody = isDark ? 'text-stone-300' : 'text-stone-600';

  // THE REVEAL
  if (showReveal && finalArchetype) {
    const arch = ARCHETYPES[finalArchetype];
    const getIcon = () => {
        if (arch.name.includes("Lunar") || arch.name.includes("Empath")) return <Moon size={48} className="text-purple-400" />;
        if (arch.name.includes("Flame") || arch.name.includes("Sun")) return <Sun size={48} className="text-amber-400" />;
        return <Sparkles size={48} className="text-stone-200" />;
    };

    return (
       <div className={`min-h-screen flex flex-col items-center justify-center p-6 text-center animate-fade-in relative overflow-hidden ${isDark ? 'bg-[#1c1917]' : 'bg-[#f5f5f4]'}`}>
         <div className="absolute inset-0 earth-texture opacity-20 z-0"></div>
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-rose-500/10 rounded-full blur-[100px] animate-pulse z-0"></div>

         <div className={`max-w-md w-full p-10 rounded-[2rem] relative overflow-hidden flex flex-col items-center border shadow-2xl z-10 animate-scale-up ${cardBg}`}>
            <div className="relative z-10 flex flex-col items-center">
              <div className="mb-4 text-rose-400 text-xs uppercase tracking-[0.4em] font-light animate-slide-down delay-100">You are a</div>
              
              <div className="w-32 h-32 rounded-full border border-white/10 flex items-center justify-center mb-8 animate-[float_6s_ease-in-out_infinite] relative shadow-2xl delay-200 bg-gradient-to-br from-stone-800 to-stone-900">
                  <div className="absolute inset-0 rounded-full border border-dashed border-white/20 animate-[spin_30s_linear_infinite]"></div>
                  <div className="drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] animate-pulse">
                     {getIcon()}
                  </div>
              </div>
              
              <h1 className={`text-4xl md:text-5xl font-serif mb-6 drop-shadow-sm leading-tight animate-fade-in-up delay-300 ${isDark ? 'text-white' : 'text-stone-900'}`}>
                {arch.name}
              </h1>
              
              <p className={`text-lg leading-relaxed italic font-light mb-8 animate-fade-in-up delay-500 ${textBody}`}>
                "{arch.tagline}"
              </p>
              
              <button 
                onClick={() => navigate('/dashboard')}
                className={`w-full px-8 py-4 rounded-xl font-serif font-medium tracking-wide transition-all duration-300 shadow-lg hover:-translate-y-1 ${isDark ? 'bg-[#292524] text-stone-200 hover:bg-[#35302e]' : 'bg-stone-900 text-white hover:bg-stone-800'}`}
              >
                Enter Your Sanctuary
              </button>
            </div>
         </div>
         <style>{`
            @keyframes scale-up { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
            .animate-scale-up { animation: scale-up 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
            
            @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
            .animate-fade-in { animation: fade-in 0.6s ease-out forwards; }
            
            @keyframes slide-down { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-slide-down { animation: slide-down 0.6s ease-out forwards; }
            
            @keyframes fade-in-up { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-fade-in-up { animation: fade-in-up 0.6s ease-out forwards; }
         `}</style>
       </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-6 text-center relative overflow-hidden ${isDark ? 'bg-[#1c1917]' : 'bg-[#f5f5f4]'}`}>
      <div className="absolute inset-0 earth-texture opacity-10"></div>
      
      <div className={`max-w-md w-full p-8 rounded-[2.5rem] relative overflow-hidden shadow-2xl border z-10 transition-all duration-500 ${cardBg}`}>
        
        {step === 0 && (
          <form onSubmit={handleNameSubmit} className="space-y-8 animate-fade-in py-4">
            <OnboardingLogo isDark={isDark} />
            <div className="space-y-2">
                <h1 className={`text-3xl font-serif ${textHeading}`}>Begin Your Journey</h1>
                <p className={textBody}>What should we call you?</p>
            </div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your Name"
              className={`w-full rounded-xl p-4 text-center text-lg focus:outline-none focus:border-rose-400 font-serif ${isDark ? 'bg-stone-900/50 border-stone-800 text-white' : 'bg-stone-50 border-stone-200 text-stone-900'}`}
              autoFocus
            />
            <button 
              type="submit" 
              disabled={!name.trim()}
              className="w-full bg-gradient-to-r from-rose-900/80 to-stone-800 text-white font-medium py-4 rounded-xl hover:opacity-90 transition-all disabled:opacity-50 border border-white/10 shadow-lg tracking-wide"
            >
              Continue
            </button>
          </form>
        )}

        {/* STEP 0.2: ZODIAC */}
        {step === 0.2 && (
            <div className="animate-fade-in space-y-6 py-4">
                <OnboardingLogo isDark={isDark} />
                <h2 className={`text-2xl font-serif ${textHeading}`}>Your Cosmic Sign?</h2>
                <p className={`text-sm ${textBody}`}>To align your daily guidance with the stars.</p>
                
                <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto custom-scrollbar p-1">
                    {ZODIAC_SIGNS.map(sign => (
                        <button
                            key={sign}
                            onClick={() => handleZodiacSelect(sign)}
                            className={`p-3 rounded-xl border text-xs font-medium transition-all ${isDark ? 'border-white/10 hover:bg-white/10 text-stone-300' : 'border-stone-200 hover:bg-stone-50 text-stone-600'}`}
                        >
                            {sign}
                        </button>
                    ))}
                </div>
            </div>
        )}

        {step === 0.5 && (
            <div className="flex flex-col items-center justify-center py-12 animate-fade-in">
                 <Heart className="text-rose-400 mb-6 animate-pulse" size={40} strokeWidth={1} />
                 <h2 className={`text-3xl font-serif mb-4 ${textHeading}`}>Welcome, {name}.</h2>
                 <p className={`font-light leading-relaxed max-w-xs mx-auto ${textBody}`}>
                     Your {zodiac} energy is safe here. We have created a space for you to explore your inner world.
                 </p>
                 <div className="mt-8 flex gap-1">
                     <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{animationDelay: '0ms'}}></div>
                     <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{animationDelay: '150ms'}}></div>
                     <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{animationDelay: '300ms'}}></div>
                 </div>
            </div>
        )}

        {step >= 1 && step <= questions.length && (
          <div className="animate-fade-in text-left">
             <div className="flex justify-between items-center mb-8">
                 <OnboardingLogo isDark={isDark} />
                 <span className={`text-xs font-serif border px-3 py-1 rounded-full ${isDark ? 'text-stone-500 border-stone-800' : 'text-stone-400 border-stone-300'}`}>
                    {step} / {questions.length}
                 </span>
             </div>
             
             <h2 className={`text-2xl font-serif mb-8 leading-snug animate-slide-down ${textHeading}`}>{questions[step - 1].text}</h2>
             
             <div className="space-y-3">
               {questions[step - 1].options.map((opt, idx) => (
                 <button
                   key={idx}
                   onClick={() => step === questions.length ? (() => { handleAnswer(opt.type); setTimeout(finishQuiz, 500); })() : handleAnswer(opt.type)}
                   className={`w-full text-left p-5 rounded-2xl border transition-all duration-300 group animate-fade-in-up opacity-0 active:scale-95 hover:-translate-y-1 ${isDark ? 'border-stone-800 bg-stone-900/30 hover:bg-stone-800 hover:border-rose-500/30 text-stone-300' : 'border-stone-200 bg-white hover:bg-stone-50 hover:border-rose-300 text-stone-600'}`}
                   style={{ animationDelay: `${idx * 100}ms`, animationFillMode: 'forwards' }}
                 >
                   <span className="group-hover:text-rose-400 transition-colors">{opt.text}</span>
                 </button>
               ))}
             </div>
          </div>
        )}
        <style>{`
            @keyframes scale-up { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
            .animate-scale-up { animation: scale-up 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
            
            @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
            .animate-fade-in { animation: fade-in 0.6s ease-out forwards; }
            
            @keyframes slide-down { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-slide-down { animation: slide-down 0.6s ease-out forwards; }
            
            @keyframes fade-in-up { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
            .animate-fade-in-up { animation: fade-in-up 0.6s ease-out forwards; }
            
            .custom-scrollbar::-webkit-scrollbar { width: 4px; }
            .custom-scrollbar::-webkit-scrollbar-thumb { background: #57534e; border-radius: 4px; }
         `}</style>
      </div>
    </div>
  );
};
