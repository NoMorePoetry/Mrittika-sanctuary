
import React, { useContext } from 'react';
import { X, Sparkles, Star, Lock, Zap, Crown } from 'lucide-react';
import { UserContext } from '../context';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureName?: string;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({ isOpen, onClose, featureName }) => {
  const { updateUser } = useContext(UserContext);

  if (!isOpen) return null;

  const handlePurchase = () => {
    // In a real app, trigger Stripe/RevenueCat/IAP here
    // For demo, just unlock it
    updateUser({ isPremium: true });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(245,158,11,0.2)] animate-scale-in">
        {/* Magical Background */}
        <div className="absolute inset-0 star-bg opacity-30"></div>
        <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-amber-600/20 to-transparent"></div>
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-amber-500/20 rounded-full blur-3xl"></div>

        <div className="relative z-10 p-8">
           <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
             <X size={24} />
           </button>

           <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center shadow-[0_0_20px_rgba(251,191,36,0.4)]">
                  <Crown size={32} className="text-white" />
              </div>
           </div>

           <div className="text-center mb-8">
              <h2 className="text-3xl font-serif text-amber-200 mb-2">Unlock Elora Gold</h2>
              <p className="text-slate-300">
                 {featureName ? `Upgrade to access ${featureName} and deeper insights.` : "Go deeper into your spiritual journey."}
              </p>
           </div>

           <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
                 <Sparkles className="text-amber-400" size={20} />
                 <span className="text-slate-200 text-sm">Unlimited AI Cosmic Scans</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
                 <Zap className="text-amber-400" size={20} />
                 <span className="text-slate-200 text-sm">Twin Flame Compatibility Details</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
                 <Lock className="text-amber-400" size={20} />
                 <span className="text-slate-200 text-sm">Shadow Work & Deep Analysis</span>
              </div>
           </div>

           <button 
             onClick={handlePurchase}
             className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-white font-bold shadow-lg shadow-amber-900/20 transition-all hover:scale-[1.02]"
           >
             Start Free Trial
             <span className="block text-xs font-normal opacity-80 mt-1">Then $4.99/week</span>
           </button>
           
           <p className="text-center text-[10px] text-slate-500 mt-4 uppercase tracking-widest">
              Cancel anytime • Secure Payment
           </p>
        </div>
      </div>
    </div>
  );
};
