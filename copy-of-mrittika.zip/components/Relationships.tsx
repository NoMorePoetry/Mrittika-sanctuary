
import React, { useContext, useState, useEffect } from 'react';
import { UserContext } from '../context';
import { getRelationshipInsight, analyzeCompatibility, analyzeConflict } from '../services/geminiService';
import { RelationshipInsight, CompatibilityResult, ConflictResult } from '../types';
import { ARCHETYPES } from '../constants';
import { Heart, Loader2, Fingerprint, EyeOff, Anchor, LockKeyhole, Sparkles, AlertTriangle, MessageSquareWarning, ShieldCheck } from 'lucide-react';

export const Relationships: React.FC = () => {
  const { user } = useContext(UserContext);
  const isDark = user.theme === 'dark';
  const archetype = user.archetype ? ARCHETYPES[user.archetype] : ARCHETYPES.lunar_empath;
  const [insight, setInsight] = useState<RelationshipInsight | null>(null);
  const [loading, setLoading] = useState(true);

  // States
  const [partnerType, setPartnerType] = useState("");
  const [compatibility, setCompatibility] = useState<CompatibilityResult | null>(null);
  const [compLoading, setCompLoading] = useState(false);
  const [conflictInput, setConflictInput] = useState("");
  const [conflictResult, setConflictResult] = useState<ConflictResult | null>(null);
  const [conflictLoading, setConflictLoading] = useState(false);

  useEffect(() => {
    const fetchInsight = async () => {
      setLoading(true);
      const data = await getRelationshipInsight(archetype.name);
      setInsight(data);
      setLoading(false);
    };
    fetchInsight();
  }, [archetype.name]);

  const handleCheckCompatibility = async () => {
      if(!partnerType) return;
      setCompLoading(true);
      const res = await analyzeCompatibility(archetype.name, partnerType);
      setCompatibility(res);
      setCompLoading(false);
  };

  const handleAnalyzeConflict = async () => {
      if(!conflictInput.trim()) return;
      setConflictLoading(true);
      const res = await analyzeConflict(conflictInput, archetype.name);
      setConflictResult(res);
      setConflictLoading(false);
  }

  // Styles
  const heading = isDark ? 'text-stone-100' : 'text-stone-900';
  const textBody = isDark ? 'text-stone-300' : 'text-stone-600';
  const cardBg = isDark ? 'bg-white/5 border-white/5' : 'bg-white border-stone-200 shadow-sm';
  const inputBg = isDark ? 'bg-white/5 border-white/10 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-800 focus:bg-white';

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
        <Loader2 className="animate-spin text-rose-400 mb-4" size={32} />
        <p className="text-stone-400 font-serif">Unveiling your heart's patterns...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-12">
      <div className="text-center mb-8">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 border ${isDark ? 'bg-rose-500/10 border-rose-500/20' : 'bg-rose-50 border-rose-100'}`}>
          <Heart className="text-rose-400" size={32} strokeWidth={1.5} />
        </div>
        <h2 className={`text-3xl font-serif ${isDark ? 'text-rose-100' : 'text-stone-900'}`}>Heart & Connection</h2>
        <p className="text-stone-500 mt-2">How the {archetype.name} loves.</p>
      </div>

      {/* Core Emotional Needs - Always Dark/Vibrant for contrast */}
      <div className="relative p-1 rounded-[2rem] bg-gradient-to-br from-stone-700/50 to-stone-800/50 shadow-xl border border-white/5">
         <div className="bg-[#1f1c1a] rounded-[1.9rem] p-8 md:p-10 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-rose-900/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
             <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-900/10 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/2"></div>
             <div className="absolute inset-0 opacity-[0.05] earth-texture"></div>

             <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
                 <div className="flex-shrink-0">
                     <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border border-white/10 flex items-center justify-center bg-gradient-to-br from-stone-800 to-stone-900 shadow-2xl relative">
                         <Anchor size={40} className="text-rose-200/80" strokeWidth={1.5} />
                         <div className="absolute -bottom-3 bg-[#292524] px-3 py-1 rounded-full border border-white/10 text-[10px] uppercase tracking-widest text-stone-400">Needs</div>
                     </div>
                 </div>

                 <div className="flex-1 text-center md:text-left">
                     <h3 className="font-serif text-2xl text-stone-200 mb-3 flex items-center justify-center md:justify-start gap-2">
                        <LockKeyhole size={20} className="text-stone-500" />
                        The Non-Negotiable
                     </h3>
                     <div className="h-px w-full bg-white/10 mb-6"></div>
                     <p className="text-xl md:text-2xl text-white font-serif leading-relaxed italic drop-shadow-sm">"{insight?.needs}"</p>
                 </div>
             </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className={`p-8 rounded-3xl border backdrop-blur-sm relative overflow-hidden group transition-colors ${cardBg}`}>
          <div className="flex items-center gap-3 mb-4 text-rose-400">
             <Fingerprint size={24} strokeWidth={1.5} />
             <h3 className={`font-serif text-xl ${heading}`}>Relationship Dynamic</h3>
          </div>
          <p className={`leading-relaxed font-light text-lg ${textBody}`}>"{insight?.dynamic}"</p>
        </div>

        <div className={`p-8 rounded-3xl border backdrop-blur-sm relative overflow-hidden group transition-colors ${cardBg}`}>
          <div className="flex items-center gap-3 mb-4 text-amber-400">
             <EyeOff size={24} strokeWidth={1.5} />
             <h3 className={`font-serif text-xl ${heading}`}>Common Misunderstanding</h3>
          </div>
          <p className={`leading-relaxed font-light text-lg ${textBody}`}>"{insight?.misunderstanding}"</p>
        </div>
      </div>

       {/* Red Flag Analyzer */}
       <div className={`mt-12 pt-8 border-t ${isDark ? 'border-white/5' : 'border-stone-200'}`}>
            <div className="text-center mb-8">
                <h2 className={`text-2xl font-serif flex items-center justify-center gap-2 ${heading}`}>
                    <MessageSquareWarning className="text-rose-400" /> Red Flag Analyzer
                </h2>
                <p className="text-stone-500 mt-2 text-sm md:text-base">
                    Was a boundary crossed? Explain the situation, and let us analyze the hidden dynamic.
                </p>
            </div>

            <div className={`p-6 md:p-8 rounded-[2rem] border max-w-3xl mx-auto shadow-lg ${isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200'}`}>
                {!conflictResult ? (
                    <div className="space-y-4">
                        <textarea 
                            value={conflictInput}
                            onChange={(e) => setConflictInput(e.target.value)}
                            placeholder="E.g. We had an argument about..."
                            className={`w-full h-32 rounded-xl p-4 focus:outline-none ${inputBg}`}
                        />
                        <button 
                            onClick={handleAnalyzeConflict}
                            disabled={!conflictInput.trim() || conflictLoading}
                            className={`w-full py-4 font-medium rounded-xl transition-all border disabled:opacity-50 flex items-center justify-center gap-2 ${isDark ? 'bg-stone-800 text-white border-white/10 hover:bg-stone-700' : 'bg-stone-900 text-white border-stone-900 hover:bg-stone-700'}`}
                        >
                            {conflictLoading ? <Loader2 className="animate-spin" /> : "Analyze Conflict"}
                        </button>
                    </div>
                ) : (
                    <div className="animate-fade-in-up space-y-6">
                        <div className={`p-6 rounded-2xl border flex items-center gap-4 ${conflictResult.boundaryStatus === 'Crossed' ? 'bg-red-500/10 border-red-500/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
                             {conflictResult.boundaryStatus === 'Crossed' ? <AlertTriangle className="text-red-500 shrink-0" size={28} /> : <ShieldCheck className="text-emerald-500 shrink-0" size={28} />}
                             <div>
                                <p className="text-xs uppercase tracking-widest opacity-70 text-stone-500">Boundary Status</p>
                                <h3 className={`text-xl font-serif font-bold ${heading}`}>{conflictResult.boundaryStatus}</h3>
                             </div>
                        </div>

                        <div className={`p-6 rounded-xl border ${cardBg}`}>
                            <h4 className={`font-serif mb-2 ${heading}`}>The Hidden Dynamic</h4>
                            <p className={`text-sm leading-relaxed ${textBody}`}>{conflictResult.analysis}</p>
                        </div>

                        <div className={`p-6 rounded-xl border ${cardBg}`}>
                            <h4 className={`font-serif mb-2 ${heading}`}>What They Might Be Feeling</h4>
                            <p className={`text-sm leading-relaxed italic ${textBody}`}>"{conflictResult.hiddenMeaning}"</p>
                        </div>

                        <div className="p-6 rounded-xl bg-gradient-to-br from-rose-900/20 to-stone-900/20 border border-rose-500/10">
                            <h4 className="text-rose-400 font-serif mb-2">Protective Advice</h4>
                            <p className={`text-sm leading-relaxed ${textBody}`}>{conflictResult.advice}</p>
                        </div>
                        
                        <button onClick={() => setConflictResult(null)} className="w-full text-center text-stone-500 hover:text-rose-500 text-sm py-2">Analyze another situation</button>
                    </div>
                )}
            </div>
       </div>


      {/* Twin Flame */}
      <div className={`mt-12 border-t pt-12 ${isDark ? 'border-white/5' : 'border-stone-200'}`}>
          <div className="text-center mb-8">
              <h2 className={`text-2xl font-serif flex items-center justify-center gap-2 ${heading}`}>
                  <Sparkles className="text-amber-400" /> Twin Flame Calculator
              </h2>
              <p className="text-stone-500 mt-2">Simulate compatibility with another soul.</p>
          </div>

          <div className={`p-8 rounded-[2rem] border max-w-2xl mx-auto shadow-2xl ${isDark ? 'bg-[#1f1c1a] border-white/5' : 'bg-white border-stone-200'}`}>
              {!compatibility ? (
                  <div className="space-y-6">
                      <p className={`text-center ${textBody}`}>Who are you connecting with?</p>
                      <div className="grid grid-cols-2 gap-3">
                          {Object.values(ARCHETYPES).filter(a => a.name !== archetype.name).slice(0, 6).map(a => (
                              <button 
                                key={a.id}
                                onClick={() => setPartnerType(a.name)}
                                className={`p-3 rounded-xl border transition-all font-serif ${partnerType === a.name ? 'bg-rose-500/20 border-rose-500/50 text-rose-500' : isDark ? 'bg-white/5 border-white/5 text-stone-400 hover:bg-white/10' : 'bg-stone-50 border-stone-200 text-stone-500 hover:bg-stone-100'}`}
                              >
                                  {a.name}
                              </button>
                          ))}
                      </div>
                      <button 
                         onClick={handleCheckCompatibility}
                         disabled={!partnerType || compLoading}
                         className={`w-full py-4 rounded-xl font-medium shadow-lg disabled:opacity-50 hover:scale-[1.02] transition-transform border border-white/10 ${isDark ? 'bg-gradient-to-r from-rose-900 to-amber-900 text-stone-100' : 'bg-gradient-to-r from-rose-500 to-amber-600 text-white'}`}
                      >
                          {compLoading ? <Loader2 className="animate-spin mx-auto" /> : "Reveal Connection"}
                      </button>
                  </div>
              ) : (
                  <div className="animate-fade-in space-y-6 text-center">
                      <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full border text-2xl font-bold ${isDark ? 'border-rose-500/30 text-rose-200 bg-white/5' : 'border-rose-200 text-rose-600 bg-rose-50'}`}>
                          {compatibility.synergyScore}%
                      </div>
                      <h3 className={`text-2xl font-serif ${heading}`}>{archetype.name} + {partnerType}</h3>
                      
                      <div className={`p-6 rounded-xl border ${cardBg}`}>
                          <p className={`font-serif italic text-lg ${isDark ? 'text-rose-200' : 'text-rose-700'}`}>"{compatibility.emotionalConnection}"</p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left relative">
                          <div className={`p-6 rounded-xl border ${cardBg}`}>
                             <span className="text-xs uppercase tracking-widest text-rose-500 block mb-2">Challenge</span>
                             <p className={`text-sm leading-relaxed ${textBody}`}>{compatibility.challengeArea}</p>
                          </div>
                          <div className={`p-6 rounded-xl border ${cardBg}`}>
                             <span className="text-xs uppercase tracking-widest text-emerald-500 block mb-2">Advice</span>
                             <p className={`text-sm leading-relaxed ${textBody}`}>{compatibility.advice}</p>
                          </div>
                      </div>
                      
                      <button onClick={() => setCompatibility(null)} className="text-stone-500 hover:text-rose-500 text-sm relative z-20">Check another match</button>
                  </div>
              )}
          </div>
      </div>
    </div>
  );
};
