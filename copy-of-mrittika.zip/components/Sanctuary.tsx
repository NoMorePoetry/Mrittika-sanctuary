import React, { useState, useRef, useEffect, useContext } from 'react';
import { 
    Play, 
    Pause, 
    CloudRain, 
    Wind, 
    Moon, 
    AlertCircle, 
    Volume1, 
    VolumeX, 
    Volume2,
    Music, 
    Waves, 
    TreePine 
} from 'lucide-react';
import { UserContext } from '../context';

export const Sanctuary: React.FC = () => {
    const { user } = useContext(UserContext);
    const isDark = user.theme === 'dark';
    const [activeTrack, setActiveTrack] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [volume, setVolume] = useState(0.5);
    const audioRef = useRef<HTMLAudioElement | null>(null);
    const fadeInterval = useRef<ReturnType<typeof setInterval> | null>(null);

    // PUBLIC DOMAIN / CC0 AMBIENT MP3s (Archive.org)
    const tracks = [
        { 
            id: 'rain', 
            name: 'Soft Window Rain', 
            icon: <CloudRain size={24} />, 
            color: 'bg-blue-500',
            // Red Library: Nature Rain – R22-17-Smooth Rain on Roof
            url: 'https://archive.org/download/Red_Library_Nature_Rain/R22-17-Smooth%20Rain%20on%20Roof.mp3'
        },
        { 
            id: 'piano', 
            name: 'Melancholic Piano', 
            icon: <Music size={24} />, 
            color: 'bg-rose-500',
            // Classical Sampler – Gymnopedie No 1 (public domain performance)
            url: 'https://archive.org/download/Classical_Sampler-9615/Gymnopedie%20No%201.mp3'
        },
        { 
            id: 'night', 
            name: 'Night Crickets', 
            icon: <Moon size={24} />, 
            color: 'bg-indigo-500',
            // Red Library: Animals Misc – R01-42-Night Time Crickets
            url: 'https://archive.org/download/Red_Library_Animals_Misc/R01-42-Night%20Time%20Crickets.mp3'
        },
        { 
            id: 'forest', 
            name: 'Deep Forest', 
            icon: <TreePine size={24} />, 
            color: 'bg-emerald-500',
            // Red Library: Animals Birds – R01-32-Small Bird Echoes in Forest
            url: 'https://archive.org/download/Red_Library_Animals_Birds/R01-32-Small%20Bird%20Echoes%20in%20Forest.mp3' 
        },
        { 
            id: 'ocean', 
            name: 'Calm Ocean', 
            icon: <Waves size={24} />, 
            color: 'bg-cyan-500',
            // Red Library: Water 1 – R23-19-Ocean Waves Crashing
            url: 'https://archive.org/download/Red_Library_Water_1/R23-19-Ocean%20Waves%20Crashing.mp3'
        },
        { 
            id: 'wind', 
            name: 'Ethereal Wind', 
            icon: <Wind size={24} />, 
            color: 'bg-stone-500',
            // Red Library: Nature Wind – R22-11-Blustery Wind Loop
            url: 'https://archive.org/download/Red_Library_Nature_Wind/R22-11-Blustery%20Wind%20Loop.mp3'
        },
    ];

    const fadeAudio = (targetVolume: number, onComplete?: () => void) => {
        const audio = audioRef.current;
        if (!audio) return;
        
        if (fadeInterval.current) clearInterval(fadeInterval.current);

        const maxVol = targetVolume === 0 ? 0 : volume;
        
        // Immediate set if close enough
        if (Math.abs(audio.volume - maxVol) < 0.01) {
            audio.volume = maxVol;
            if (onComplete) onComplete();
            return;
        }

        const step = maxVol > audio.volume ? 0.05 : -0.05;
        
        fadeInterval.current = setInterval(() => {
            const a = audioRef.current;
            if (!a) return;
            
            let newVolume = a.volume + step;
            if (newVolume < 0) newVolume = 0;
            if (newVolume > 1) newVolume = 1;
            
            const reachedTarget = (step > 0 && newVolume >= maxVol) || (step < 0 && newVolume <= 0);
            
            if (reachedTarget) {
                a.volume = maxVol;
                if (fadeInterval.current) clearInterval(fadeInterval.current);
                if (onComplete) onComplete();
            } else {
                a.volume = newVolume;
            }
        }, 50);
    };

    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newVol = parseFloat(e.target.value);
        setVolume(newVol);
        if (audioRef.current && activeTrack) {
            audioRef.current.volume = newVol;
        }
    };

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;

        let isCancelled = false;

        const playTrack = async () => {
            try {
                if (activeTrack) {
                    const track = tracks.find(t => t.id === activeTrack);
                    if (track) {
                        // If source changed, update it
                        if (!audio.src || !audio.src.includes(track.url)) {
                            audio.pause(); 
                            audio.src = track.url;
                            audio.volume = 0; 
                        }
                        
                        const playPromise = audio.play();
                        if (playPromise !== undefined) {
                            playPromise
                                .then(() => {
                                    if (!isCancelled) {
                                        setError(null);
                                        fadeAudio(volume);
                                    } else {
                                        audio.pause();
                                    }
                                })
                                .catch((err) => {
                                    if (err.name !== 'AbortError') {
                                        console.error("Playback prevented:", err);
                                        if (!isCancelled) setError("Stream blocked. Check connection.");
                                    }
                                });
                        }
                    }
                } else {
                    // Fade out then pause
                    fadeAudio(0, () => {
                        if (!isCancelled) audio.pause();
                    });
                }
            } catch (err) {
                console.error("Audio playback error:", err);
                if (!isCancelled) setError("Unable to play stream.");
            }
        };

        playTrack();

        return () => {
            isCancelled = true;
            if (fadeInterval.current) clearInterval(fadeInterval.current);
        };
    }, [activeTrack, tracks, volume]);

    const toggleTrack = (id: string) => {
        if (activeTrack === id) {
            setActiveTrack(null);
        } else {
            setError(null);
            setActiveTrack(id);
        }
    };

    const handleMuteClick = () => {
        if (audioRef.current) {
            audioRef.current.volume = 0;
        }
        setVolume(0);
    };

    return (
        <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-24">
            <div className="text-center mb-8 px-4">
                <h2 className={`text-3xl font-serif mb-2 ${isDark ? 'text-indigo-100' : 'text-indigo-900'}`}>
                    Sonic Sanctuary
                </h2>
                <p className={`${isDark ? 'text-slate-400' : 'text-stone-500'}`}>
                    Melancholic frequencies to soothe your soul.
                </p>
            </div>

            {/* Direct MP3 Audio Tag */}
            <audio ref={audioRef} loop className="hidden" preload="auto" />

            {error && (
                <div className="mx-4 bg-red-900/20 border border-red-500/30 p-4 rounded-xl text-red-400 flex items-center justify-center gap-2 text-sm mb-6 animate-pulse">
                    <AlertCircle size={16} />
                    {error}
                </div>
            )}

            {activeTrack && (
                <div className={`mx-auto max-w-xs mb-8 p-4 rounded-2xl flex items-center gap-4 border animate-fade-in-up ${
                    isDark ? 'bg-slate-900/50 border-white/10' : 'bg-white border-stone-200 shadow-sm'
                }`}>
                    <button 
                        onClick={handleMuteClick} 
                        className="text-stone-500 hover:text-indigo-500"
                    >
                        {volume === 0 ? <VolumeX size={20} /> : <Volume1 size={20} />}
                    </button>
                    <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.01" 
                        value={volume}
                        onChange={handleVolumeChange}
                        className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400"
                    />
                    <span className="text-xs font-mono text-stone-500 w-8 text-right">
                        {Math.round(volume * 100)}%
                    </span>
                </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 px-4">
                {tracks.map(track => (
                    <button 
                        key={track.id}
                        onClick={() => toggleTrack(track.id)}
                        className={`relative p-6 md:p-8 rounded-3xl border overflow-hidden transition-all duration-500 group text-left ${
                            activeTrack === track.id 
                                ? 'bg-slate-800/90 shadow-[0_0_30px_rgba(139,92,246,0.2)] border-indigo-500/50 scale-[1.02]' 
                                : isDark 
                                    ? 'bg-slate-900/50 hover:bg-slate-800 border-white/10'
                                    : 'bg-white hover:bg-stone-50 border-stone-200 shadow-sm'
                        }`}
                    >
                        {activeTrack === track.id && (
                            <div className="absolute inset-0 flex items-end justify-center gap-1 opacity-20 pb-0 pointer-events-none">
                                {[...Array(20)].map((_, i) => (
                                    <div 
                                        key={i} 
                                        className={`w-2 ${track.color} rounded-t-full animate-bounce`} 
                                        style={{ 
                                            height: `${30 + (i % 5) * 10}%`,
                                            animationDuration: `${0.6 + (i % 5) * 0.1}s` 
                                        }}
                                    />
                                ))}
                            </div>
                        )}

                        <div className="relative z-10 flex flex-col items-center gap-4">
                            <div className={`w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center ${
                                activeTrack === track.id
                                    ? 'bg-white text-slate-900 scale-110'
                                    : isDark
                                        ? 'bg-white/10 text-slate-300 group-hover:bg-white/20'
                                        : 'bg-stone-100 text-stone-500'
                            } transition-all duration-300 shadow-lg`}>
                                {activeTrack === track.id ? <Pause size={24} /> : <Play size={24} className="ml-1" />}
                            </div>
                            
                            <div className="text-center">
                                <h3 className={`text-lg md:text-xl font-serif ${isDark ? 'text-white' : 'text-stone-800'}`}>
                                    {track.name}
                                </h3>
                                <p className={`text-xs md:text-sm mt-1 flex items-center justify-center gap-1 ${
                                    isDark ? 'text-slate-500' : 'text-stone-400'
                                }`}>
                                    {activeTrack === track.id ? (
                                        <span className="flex items-center gap-2 text-indigo-500 animate-pulse font-medium">
                                            <Volume2 size={12} /> Now Playing
                                        </span>
                                    ) : (
                                        'Tap to listen'
                                    )}
                                </p>
                            </div>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
};
