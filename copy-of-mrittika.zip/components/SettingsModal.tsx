
import React, { useState, useEffect } from 'react';
import { X, Save, Key } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [apiKey, setApiKey] = useState('');
  
  useEffect(() => {
    const stored = localStorage.getItem('mrittika_api_key');
    if (stored) setApiKey(stored);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    localStorage.setItem('mrittika_api_key', apiKey.trim());
    onClose();
    window.location.reload(); // Reload to refresh AI service with new key
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#1c1917] border border-white/10 rounded-2xl p-6 shadow-2xl animate-fade-in-up relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-stone-500 hover:text-white">
          <X size={20} />
        </button>
        
        <div className="flex items-center gap-3 mb-6">
           <div className="p-3 bg-stone-800 rounded-full">
              <Key className="text-rose-400" size={20} />
           </div>
           <h2 className="text-xl font-serif text-stone-100">API Settings</h2>
        </div>

        <div className="space-y-4">
           <p className="text-sm text-stone-400">
             Enter your Google Gemini API Key to enable all AI features. 
             Your key is stored locally on your device.
           </p>
           
           <div className="space-y-2">
              <label className="text-xs uppercase tracking-wider text-stone-500 font-semibold">API Key</label>
              <input 
                type="password" 
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full p-4 rounded-xl bg-stone-900 border border-white/10 text-white focus:border-rose-500 outline-none"
              />
           </div>

           <button 
             onClick={handleSave}
             className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-colors"
           >
             <Save size={18} /> Save & Reload
           </button>
           
           <p className="text-[10px] text-stone-600 text-center mt-2">
             Get a key from <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-rose-400 hover:underline">Google AI Studio</a>
           </p>
        </div>
      </div>
    </div>
  );
};
