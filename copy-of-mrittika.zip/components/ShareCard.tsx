
import React, { useRef, useState } from 'react';
import { Share2, Feather, Leaf, Copy, Check, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';

interface ShareCardProps {
  title: string;
  content: string;
  subtext?: string;
  theme?: 'clay' | 'rose' | 'sage' | 'stone' | 'purple';
}

// Unique Logo 3: The Feather (Sharing/Messages)
const ShareLogo = () => (
    <div className="flex items-center gap-2 text-white/40">
        <Leaf size={14} />
        <span className="text-[10px] uppercase tracking-[0.4em] font-light">Mrittika</span>
    </div>
);

export const ShareCard: React.FC<ShareCardProps> = ({ title, content, subtext, theme = 'clay' }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [generating, setGenerating] = useState(false);

  // Enhanced Theme Configuration for nuanced visuals
  const themeConfig = {
    clay: {
      gradient: "from-[#5d4037] via-[#4e342e] to-[#3e2723] border-[#8d6e63]/30",
      blob: "bg-[#ffab91]/20", 
      text: "text-orange-100",
      subtext: "text-orange-200/70"
    },
    rose: {
      gradient: "from-[#881337] via-[#4c0519] to-[#2a0a12] border-[#fda4af]/20",
      blob: "bg-[#fb7185]/20",
      text: "text-rose-100",
      subtext: "text-rose-200/70"
    },
    sage: {
      gradient: "from-[#1a2e1a] via-[#142518] to-[#0f1f12] border-[#4ade80]/20",
      blob: "bg-[#86efac]/10",
      text: "text-emerald-100",
      subtext: "text-emerald-200/70"
    },
    stone: {
      gradient: "from-[#44403c] via-[#292524] to-[#1c1917] border-[#a8a29e]/20",
      blob: "bg-[#d6d3d1]/10",
      text: "text-stone-200",
      subtext: "text-stone-400/70"
    },
    purple: {
      gradient: "from-[#4c1d95] via-[#2e1065] to-[#180a33] border-[#a78bfa]/20",
      blob: "bg-[#c4b5fd]/15",
      text: "text-purple-100",
      subtext: "text-purple-200/70"
    }
  };

  const currentTheme = themeConfig[theme];

  const handleShareImage = async () => {
    if (cardRef.current && !generating) {
      setGenerating(true);
      try {
        const canvas = await html2canvas(cardRef.current, {
          backgroundColor: null,
          scale: 2,
          logging: false
        });
        
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], 'mrittika-insight.png', { type: 'image/png' });
            if (navigator.share && navigator.canShare({ files: [file] })) {
              navigator.share({
                files: [file],
                title: 'My Mrittika Insight',
                text: 'Discover your inner earth with Mrittika.'
              });
            } else {
              const link = document.createElement('a');
              link.download = 'mrittika-insight.png';
              link.href = canvas.toDataURL();
              link.click();
            }
          }
          setGenerating(false);
        });
      } catch (err) {
        console.error("Error creating share image", err);
        setGenerating(false);
      }
    }
  };

  const handleShareText = async () => {
    const textToShare = `${title}\n\n"${content}"\n\n${subtext || ''}\n\nDiscover your inner earth with Mrittika.`;
    
    if (navigator.share && navigator.canShare({ text: textToShare })) {
        try {
            await navigator.share({
                title: 'Mrittika Insight',
                text: textToShare
            });
        } catch (err) {
            console.log('Share cancelled');
        }
    } else {
        // Fallback to clipboard
        try {
            await navigator.clipboard.writeText(textToShare);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error('Failed to copy', err);
        }
    }
  };

  return (
    <div 
        className="relative group h-full" 
        role="article" 
        aria-label={`Share card: ${title}`}
    >
      <div 
        ref={cardRef} 
        className={`relative overflow-hidden p-8 md:p-12 rounded-[1.5rem] border backdrop-blur-xl bg-gradient-to-br ${currentTheme.gradient} text-center transition-transform duration-300 h-full flex flex-col justify-center shadow-2xl`}
      >
        {/* Organic Flow Backgrounds - Nuanced blobs */}
        <div className={`absolute top-0 left-0 w-72 h-72 ${currentTheme.blob} rounded-full blur-[80px] -translate-x-1/4 -translate-y-1/4 animate-pulse duration-[4s]`}></div>
        <div className={`absolute bottom-0 right-0 w-64 h-64 ${currentTheme.blob} rounded-full blur-[80px] translate-x-1/4 translate-y-1/4 animate-pulse duration-[5s]`}></div>
        
        {/* Grain Texture Overlay */}
        <div className="absolute inset-0 opacity-[0.07] mix-blend-overlay pointer-events-none" style={{backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`}}></div>

        {/* Loading Overlay during generation */}
        {generating && (
            <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in">
                <Loader2 className="animate-spin text-white/80 mb-2" size={32} />
                <span className="text-white/80 text-xs font-serif tracking-widest">Capturing...</span>
            </div>
        )}

        <div className="relative z-10 flex flex-col items-center gap-6">
          <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-white/5 backdrop-blur-sm shadow-sm">
             <Feather size={20} className="text-white/80" aria-hidden="true" />
          </div>
          
          <h3 className={`font-serif text-lg tracking-[0.2em] uppercase opacity-80 ${currentTheme.text}`}>{title}</h3>
          
          <div className="w-12 h-px bg-white/20"></div>
          
          <div className="relative">
              <p className="font-serif text-xl md:text-2xl leading-relaxed italic text-stone-100 drop-shadow-sm px-2 select-text">
                "{content}"
              </p>
          </div>
          
          {subtext && <p className={`text-xs uppercase tracking-[0.2em] mt-4 opacity-60 font-medium ${currentTheme.subtext}`}>{subtext}</p>}
          
          <div className="mt-8">
            <ShareLogo />
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 z-20 focus-within:opacity-100">
        <button 
            onClick={handleShareText}
            className="p-3 rounded-full bg-black/20 hover:bg-black/40 text-stone-300 backdrop-blur-md border border-white/10 shadow-lg hover:scale-105 transition-all focus:outline-none focus:ring-2 focus:ring-white/50"
            title={copied ? "Copied!" : "Copy Text"}
            aria-label={copied ? "Text copied to clipboard" : "Share content as text"}
        >
            {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
        </button>

        <button 
            onClick={handleShareImage}
            disabled={generating}
            className="p-3 rounded-full bg-black/20 hover:bg-black/40 text-stone-300 backdrop-blur-md border border-white/10 shadow-lg hover:scale-105 transition-all focus:outline-none focus:ring-2 focus:ring-white/50 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Share Image"
            aria-label="Generate and share image card"
        >
            {generating ? <Loader2 size={16} className="animate-spin" /> : <Share2 size={16} />}
        </button>
      </div>
    </div>
  );
};
