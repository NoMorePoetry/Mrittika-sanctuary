
import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Moon, Heart, User, Sparkles, History, Smartphone, Flower, FlaskConical, Music, Sun, Settings } from 'lucide-react';
import { UserContext } from '../context';
import { ARCHETYPES } from '../constants';

const SidebarLogo = () => (
  <div className="relative w-11 h-11 flex items-center justify-center bg-gradient-to-br from-stone-700 to-stone-900 rounded-xl shadow-lg border border-white/10">
    <Flower className="text-rose-200/90" size={22} strokeWidth={1.5} />
    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-amber-500/50 rounded-full blur-sm"></div>
  </div>
);

export const Sidebar: React.FC = () => {
  const { user, updateUser, toggleSettings } = useContext(UserContext);
  const archetype = user.archetype ? ARCHETYPES[user.archetype] : null;
  const isDark = user.theme === 'dark';

  const toggleTheme = () => {
    updateUser({ theme: isDark ? 'light' : 'dark' });
  };

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group ${
      isActive 
        ? isDark 
            ? 'text-rose-100 bg-white/[0.03] border border-white/5 shadow-[0_0_15px_rgba(255,255,255,0.02)]' 
            : 'text-rose-900 bg-stone-100 border border-stone-200 shadow-sm'
        : isDark 
            ? 'text-stone-400 hover:text-stone-200 hover:bg-white/[0.02]' 
            : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
    }`;

  return (
    <aside className={`fixed left-0 top-0 h-full w-64 ${isDark ? 'bg-[#1c1917]/90 border-white/5' : 'bg-[#f5f5f4]/90 border-stone-200'} backdrop-blur-xl border-r hidden md:flex flex-col z-20 transition-colors duration-300`}>
      <div className="p-8 pb-6 flex items-center gap-3">
        <SidebarLogo />
        <div>
          <h1 className={`text-2xl font-bold font-serif tracking-widest ${isDark ? 'text-stone-100' : 'text-stone-800'}`}>
            Mrittika
          </h1>
          <p className="text-[10px] text-stone-500 uppercase tracking-wider">Earth & Soul</p>
        </div>
      </div>
      
      {archetype && (
        <div className="px-8 mb-6">
          <div className={`px-4 py-2 rounded-lg border ${isDark ? 'bg-white/5 border-white/5' : 'bg-stone-200/50 border-stone-200'}`}>
            <p className="text-[10px] text-stone-500 uppercase tracking-widest mb-1">Your Essence</p>
            <p className={`text-xs font-serif ${isDark ? 'text-stone-300' : 'text-stone-700'}`}>{archetype.name}</p>
          </div>
        </div>
      )}

      <nav className="flex-1 px-4 py-2 space-y-1 overflow-y-auto custom-scrollbar">
        <NavLink to="/dashboard" className={linkClass}>
          <Home size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Sanctuary</span>
        </NavLink>
        <NavLink to="/lab" className={linkClass}>
          <FlaskConical size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Inner Lab</span>
        </NavLink>
        <NavLink to="/sanctuary" className={linkClass}>
          <Music size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Soundscapes</span>
        </NavLink>
        <NavLink to="/daily" className={linkClass}>
          <Sparkles size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Daily Wisdom</span>
        </NavLink>
        <NavLink to="/mood" className={linkClass}>
          <Moon size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Mood Mirror</span>
        </NavLink>
        <NavLink to="/relationships" className={linkClass}>
          <Heart size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Heart Insight</span>
        </NavLink>
        <NavLink to="/profile" className={linkClass}>
          <User size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">My Archetype</span>
        </NavLink>
        <NavLink to="/history" className={linkClass}>
          <History size={18} className="group-hover:scale-105 transition-transform" />
          <span className="font-medium text-sm tracking-wide">Journey</span>
        </NavLink>
      </nav>

      <div className={`p-6 border-t space-y-4 ${isDark ? 'border-white/5' : 'border-stone-200'}`}>
         <button 
           onClick={toggleTheme}
           className={`w-full flex items-center justify-center gap-2 py-2 rounded-xl border transition-all duration-300 ${
             isDark 
               ? 'bg-white/5 border-white/10 hover:bg-white/10 text-stone-300' 
               : 'bg-stone-100 border-stone-200 hover:bg-stone-200 text-stone-600'
           }`}
         >
            {isDark ? <Sun size={14} /> : <Moon size={14} />}
            <span className="text-xs font-medium tracking-wide">{isDark ? 'Light Mode' : 'Dark Mode'}</span>
         </button>

         <button 
           onClick={toggleSettings}
           className={`w-full flex items-center justify-center gap-2 py-2 rounded-xl border transition-all duration-300 opacity-60 hover:opacity-100 ${
             isDark 
               ? 'text-stone-400 hover:text-stone-200 border-transparent hover:border-white/5 hover:bg-white/5' 
               : 'text-stone-500 hover:text-stone-800 border-transparent hover:border-stone-200 hover:bg-stone-100'
           }`}
         >
            <Settings size={14} />
            <span className="text-xs font-medium tracking-wide">Settings</span>
         </button>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: ${isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'};
          border-radius: 10px;
        }
      `}</style>
    </aside>
  );
};
