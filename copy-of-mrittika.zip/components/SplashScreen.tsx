
import React, { useEffect, useState } from 'react';
import { Flower, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState(0);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500); // Logo
    const t2 = setTimeout(() => setPhase(2), 1500); // Text
    const t3 = setTimeout(() => setIsReady(true), 2500); // Ready

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  const handleEnter = () => {
    if (!isReady) return;
    setPhase(3); // Fade out
    setTimeout(() => {
        onComplete();
    }, 1000);
  };

  return (
    <div 
        className={`fixed inset-0 z-[10000] flex flex-col items-center justify-center bg-[#1c1917] transition-opacity duration-1000 cursor-pointer ${phase === 3 ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
        onClick={handleEnter}
    >
      <div className="absolute inset-0 opacity-10 earth-texture pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] bg-rose-900/10 rounded-full blur-[120px] animate-pulse pointer-events-none"></div>

      <div className={`transition-all duration-1000 transform relative ${phase >= 1 ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
         <div className="absolute inset-0 bg-rose-500/20 rounded-full blur-2xl animate-[pulse_3s_ease-in-out_infinite]"></div>
         
         <div className="w-28 h-28 rounded-[2rem] bg-gradient-to-br from-stone-800 to-stone-900 border border-white/10 shadow-[0_0_50px_rgba(244,63,94,0.15)] flex items-center justify-center mb-8 relative overflow-hidden z-10">
            <div className="absolute inset-0 earth-texture opacity-20"></div>
            <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent"></div>
            <Flower className="text-rose-200 drop-shadow-[0_0_10px_rgba(253,164,175,0.5)]" size={56} strokeWidth={1} />
         </div>
      </div>

      <div className={`text-center transition-all duration-1000 delay-300 transform relative z-10 ${phase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
        <h1 className="text-4xl md:text-5xl font-serif text-stone-100 tracking-[0.2em] mb-4 drop-shadow-lg">MRITTIKA</h1>
        
        <div className="w-12 h-px bg-gradient-to-r from-transparent via-rose-500/50 to-transparent mx-auto mb-6"></div>
        
        <p className="text-rose-100/90 text-lg md:text-xl font-serif italic font-light tracking-wide mb-2">
          "Where your soul finds its roots."
        </p>
        <p className="text-stone-500 text-[10px] uppercase tracking-[0.3em]">Earth & Spirit</p>
      </div>

      <div className={`absolute bottom-20 transition-all duration-700 ${isReady ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <div className="flex flex-col items-center gap-2 animate-bounce">
              <Sparkles size={16} className="text-rose-300/50" />
              <span className="text-stone-400 text-xs uppercase tracking-widest font-light">Tap to Begin</span>
          </div>
      </div>
    </div>
  );
};
