
export const PUSH_NOTIFICATIONS = [
  { title: "Someone is thinking of you...", body: "Your energy just shifted. Open to see why." },
  { title: "A hidden emotion detected", body: "You're ignoring a feeling that's trying to guide you." },
  { title: "Relationship Update", body: "The silence between you two speaks volumes. Decode it now." },
  { title: "Your Aura shifted", body: "You've moved from Rose Quartz to Storm Grey. Find out why." },
  { title: "Don't text them yet.", body: "Read this before you hit send. Trust us." },
  { title: "Cosmic Alert", body: "A cycle from your past is closing today." },
  { title: "Your Archetype is active", body: "Your 'Lunar Empath' side is taking on too much today." },
  { title: "Message from the Universe", body: "The sign you asked for? This is it." },
  { title: "Face Scan Complete", body: "Your eyes are showing 'High Stress' but 'Romantic Glow'. See the analysis." },
  { title: "Dream Insight", body: "That dream wasn't random. It was a warning." },
  { title: "He misses you.", body: "But not in the way you think. Tap to reveal." },
  { title: "Self-Love Check", body: "You're being too hard on yourself today." }
];
