
export const BARNUM_CATEGORIES = {
  RELATIONSHIPS: "relationships",
  CRUSHES: "crushes",
  EXES: "exes",
  SELF_LOVE: "self_love",
  FRIENDS: "friends",
  PREDICTIONS: "predictions",
  WOUNDS: "wounds",
  HEALING: "healing",
  ARCHETYPES: "archetypes"
} as const;

export type CategoryKey = keyof typeof BARNUM_CATEGORIES;

export const BARNUM_PROMPTS: Record<string, string[]> = {
  relationships: [
    "You often give more love than you receive, silently hoping they will notice the imbalance without you having to say it.",
    "There is a conversation you have been rehearsing in your mind, but you are waiting for the 'perfect' moment that never seems to arrive.",
    "You crave deep connection, but when someone gets too close, a part of you instinctively checks the exits.",
    "You are holding onto a relationship dynamic that no longer serves you, simply because the history feels heavier than the future.",
    "You value loyalty above all else, which makes it devastating when you feel even a micro-betrayal.",
    "You have been suppressing your need for reassurance because you don't want to appear 'needy', but your silence is creating distance.",
    "Someone close to you relies on your strength, but they have no idea how tired you actually are.",
    "You attract partners who need fixing because your love language is nurturing, but you are starting to realize you need to be nurtured too.",
    "You notice shifts in energy that others miss; you knew something was wrong long before they admitted it.",
    "You want to be chosen, not just accepted."
  ],
  crushes: [
    "You are analyzing their silence more than their words. The hesitation you feel isn't rejection, it's protection.",
    "You are waiting for a sign, but you've already seen it—you're just afraid to trust your intuition because it scares you.",
    "There is an intense magnetic pull here, but you are worried that if you show your hand, you will lose the power dynamic.",
    "You are replaying a specific moment in your head, wondering if it meant as much to them as it did to you.",
    "They are thinking about you more than they let on, but they are intimidated by your energy.",
    "You are afraid that your intensity will scare them away, so you are playing it cool—but playing it cool is exhausting you.",
    "You often look for them in crowded rooms even when you know they aren't there.",
    "You feel a connection that defies logic, as if you have known them before this lifetime.",
    "You are holding back a compliment because you don't want to give them the satisfaction of knowing they have this effect on you.",
    "The tension between you is unspoken, but it is the loudest thing in the room."
  ],
  exes: [
    "Part of you misses them, but the stronger part of you misses who you were before the pain.",
    "You are still carrying a question that they never gave you a satisfying answer to.",
    "You have forgiven them in your head, but your body still holds the memory of how they made you feel small.",
    "You occasionally check on them not because you want them back, but to reassure yourself that you are doing okay without them.",
    "You learned to be independent because, at some point, relying on them felt dangerous.",
    "There is a song you skip because it brings back a specific memory you aren't ready to process yet.",
    "You grieved the potential of the relationship more than the reality of it.",
    "They mistook your silence for agreement, when really, it was you checking out emotionally.",
    "You are afraid that you will never love with that same reckless abandon again.",
    "Closure didn't come from their apology; it came from your realization that you deserve better."
  ],
  self_love: [
    "You are so hard on yourself because you see your own potential so clearly.",
    "You have been putting everyone else's needs on your to-do list and leaving yourself for 'later'—but later never comes.",
    "You criticize yourself for not being 'further ahead', ignoring how many mountains you have already climbed.",
    "You possess a quiet resilience that people often mistake for ease; they don't see the effort it takes to be you.",
    "You are learning to set boundaries, but you still feel a twinge of guilt every time you say 'no'.",
    "You need to forgive yourself for the things you did when you were just trying to survive.",
    "Your inner child is still waiting for you to tell her that she is safe now.",
    "You are beautiful not for how you look, but for the way you refuse to give up on love despite everything.",
    "You are allowing yourself to be messy, flawed, and unfinished, and that is where your true power lies.",
    "You deserve the same kindness you so freely give to strangers."
  ],
  friends: [
    "You are the 'therapist' friend, but you rarely tell them when you are struggling.",
    "You have outgrown a friendship, and the distance feels awkward, but it is necessary for your growth.",
    "You feel a pang of loneliness even when you are surrounded by people, because you crave depth over presence.",
    "Someone in your circle is jealous of your light, even if they smile to your face.",
    "You are loyal to a fault, often keeping secrets that burden you just to protect others.",
    "You miss a friendship that ended without a real explanation.",
    "You bring people together, but sometimes you wonder who would initiate if you stopped trying.",
    "You are realizing that 'history' is not a good enough reason to keep someone in your life who drains you.",
    "A friend looks up to you more than you realize.",
    "You need to spend time with people who recharge your battery, not just drain it."
  ],
  predictions: [
    "A sudden clarity is coming regarding a decision you have been avoiding for weeks.",
    "Someone from your past will resurface soon, but this time, you will have the upper hand.",
    "The confusion you feel right now is the chaos before a major transformation.",
    "Financial flow is blocked by your anxiety; release the fear, and the resources will appear.",
    "Next month brings a romantic opportunity that feels different—calmer, safer.",
    "You are about to step into a role that feels too big for you, but you are ready.",
    "A message is coming that will confirm what your intuition has been screaming at you.",
    "You will soon release a burden you didn't even realize you were carrying.",
    "The universe is aligning a 'coincidence' that will solve a problem you've been stressing over.",
    "Your patience is about to pay off in a way you didn't expect."
  ],
  wounds: [
    "You learned to read the room instantly because your safety once depended on predicting other people's moods.",
    "You over-explain yourself because you are terrified of being misunderstood.",
    "You have a fear of being 'too much', so you dilute your emotions to make them palatable for others.",
    "You struggle to ask for help because you don't want to be a burden.",
    "Your independence is a trauma response; you decided long ago that you are the only one you can rely on.",
    "You apologize for taking up space.",
    "You feel responsible for other people's emotions, as if it is your job to fix their bad days.",
    "You find it hard to relax because your body is always waiting for the other shoe to drop.",
    "You sabotage happiness because peace feels unfamiliar and suspicious to you.",
    "You hide your vulnerability behind a mask of humor or competence."
  ],
  healing: [
    "Healing for you looks like doing nothing and not feeling guilty about it.",
    "You are breaking a generational cycle of silence.",
    "It is okay to grieve the childhood you didn't have.",
    "You are learning that your worth is not tied to your productivity.",
    "The trigger you felt today was not a setback; it was an opportunity to reparent yourself.",
    "You are slowly learning to trust your own judgment again.",
    "You are allowed to change your mind, your boundaries, and your life path.",
    "You are replacing 'I should' with 'I choose'.",
    "You are becoming the person you needed when you were younger.",
    "Your sensitivity is not a weakness; it is the tool you will use to heal others."
  ],
  archetypes: [
    "As a Lunar Empath, your mood is tied to the moon; rest when she is hidden.",
    "As a Quiet Flame, your presence is enough; you do not need to perform to be loved.",
    "As a Gentle Storm, do not apologize for your thunder; it clears the air.",
    "As a Hidden Wildflower, you bloom in your own time, not when society tells you to.",
    "As a Velvet Anchor, remember that you cannot hold everyone else down if you are drifting yourself.",
    "As a Starlit Weaver, trust the connections you see, even if others call them coincidences.",
    "As a Crystal Mirror, it is safe to fog up sometimes; you do not always have to be clear.",
    "As an Oceanic Sage, your depth is a gift, but do not forget to swim on the surface sometimes."
  ]
};
