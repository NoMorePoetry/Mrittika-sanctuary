
import { GoogleGenAI, Type } from "@google/genai";
import { MoodAnalysisResult, RelationshipInsight, AuraResult, MessageAnalysisResult, FaceScanResult, CompatibilityResult, ConflictResult } from "../types";

// Dynamic AI Instance Generator
const getAI = () => {
  const userKey = localStorage.getItem('mrittika_api_key');
  const apiKey = userKey || process.env.API_KEY || '';
  return new GoogleGenAI({ apiKey });
};

// --- FALLBACK DATA GENERATORS ---
const getFallbackMood = (input: string): MoodAnalysisResult => ({
  emotionalTone: "Quiet Transformation",
  keyDesire: "To feel grounded amidst the shifting tides",
  hiddenFear: "That you are falling behind while others move forward",
  validatingStatement: "You are currently in a chrysalis phase. The stillness you feel is not stagnation, but the necessary gathering of energy before your next bloom."
});

const getFallbackRelationship = (): RelationshipInsight => ({
  dynamic: "You are the emotional anchor, often stabilizing the connection while secretly craving to be the one held.",
  needs: "A partner who can read your silence as fluently as your words.",
  misunderstanding: "Your need for solitude is often mistaken for withdrawal or lack of interest."
});

const getFallbackAura = (): AuraResult => ({
  colorName: "Ethereal Indigo",
  colorCode: "#4b0082",
  meaning: "Your intuition is currently heightened, acting as a protective veil around your energy.",
  prediction: "Trust the subtle nudges you feel this week; they are leading you to a surprising clarity."
});

const getFallbackMessageAnalysis = (): MessageAnalysisResult => ({
  hiddenEmotion: "Hesitation mixed with a desire for approval.",
  realMeaning: "They want to connect but are afraid of overstepping or being rejected.",
  redFlagRating: "Safe",
  advice: "Respond with warmth but maintain your boundaries. Let them come to you."
});

const getFallbackFaceScan = (): FaceScanResult => ({
  vibe: "Resilient Grace",
  hiddenEmotion: "A quiet weariness you hide behind a polite smile.",
  romanticGlow: "Subtle but magnetic",
  soulMessage: "Your eyes hold the wisdom of someone who has loved deeply and learned difficult lessons.",
  stressLevel: 42,
  emotionalFatigue: 55,
  confidence: 68
});

export const analyzeMood = async (input: string, archetype: string): Promise<MoodAnalysisResult> => {
  try {
    const ai = getAI();
    const prompt = `
      You are a mystical, empathetic guide for a woman who identifies as the "${archetype}" archetype.
      She has shared this thought/feeling: "${input}".
      
      Your task is to analyze this using the "Barnum Effect" - create statements that feel deeply personal but apply broadly to this emotional state.
      
      Return a JSON object with:
      1. emotionalTone: A 2-3 word poetic description of her vibe (e.g., "Quiet Melancholy", "Restless Spark").
      2. keyDesire: What she truly wants right now (e.g., "To be understood without explaining").
      3. hiddenFear: A subconscious fear she might be facing (e.g., "That your efforts are going unnoticed").
      4. validatingStatement: A 2-sentence comforting, validating insight using Barnum style language.
      
      Tone: Soft, feminine, validating, insightful, slightly mystical.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            emotionalTone: { type: Type.STRING },
            keyDesire: { type: Type.STRING },
            hiddenFear: { type: Type.STRING },
            validatingStatement: { type: Type.STRING },
          },
          required: ["emotionalTone", "keyDesire", "hiddenFear", "validatingStatement"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as MoodAnalysisResult;
  } catch (error) {
    console.warn("Mood API failed, using fallback", error);
    return getFallbackMood(input);
  }
};

export const getRelationshipInsight = async (archetype: string): Promise<RelationshipInsight> => {
  try {
     const ai = getAI();
     const prompt = `
      Generate a relationship insight for a woman who is the "${archetype}" archetype.
      Use the Barnum Effect to make it sound universally relatable yet specific.
      
      Return JSON:
      1. dynamic: How she acts in relationships (e.g., "You give more than you take").
      2. needs: What she secretly needs (e.g., "Someone who listens to the silence between your words").
      3. misunderstanding: What partners often get wrong about her.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dynamic: { type: Type.STRING },
            needs: { type: Type.STRING },
            misunderstanding: { type: Type.STRING },
          },
          required: ["dynamic", "needs", "misunderstanding"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text) as RelationshipInsight;

  } catch (error) {
    console.warn("Relationship API failed, using fallback", error);
    return getFallbackRelationship();
  }
}

export const getDailyReflection = async (archetype: string): Promise<string> => {
  try {
    const ai = getAI();
    const prompt = `
      Write a short, 2-sentence daily horoscope/reflection for the "${archetype}". 
      Start with "Recently, you've noticed..." or "You are feeling...".
      Use the Forer/Barnum effect: generalized traits that seem personal.
      Tone: Mystical, soft, supportive.
    `;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text || "The stars are aligning to bring clarity to the confusion you have been feeling lately.";
  } catch (e) {
    console.warn("Daily API failed, using fallback", e);
    return "You have been carrying a heavy burden silently, but relief is coming from an unexpected source. Trust that the universe is rearranging things in your favor.";
  }
}

export const getSmartBarnumPrompt = async (archetype: string, lastMood?: MoodAnalysisResult): Promise<string> => {
  try {
    const ai = getAI();
    const context = lastMood 
      ? `The user recently felt "${lastMood.emotionalTone}" and desired "${lastMood.keyDesire}".` 
      : "The user has been quiet lately.";

    const prompt = `
      Generate a hyper-specific "Barnum Effect" insight for a "${archetype}".
      Context: ${context}
      
      This should feel like a "Personal Echo" - a realization about their current state of life.
      It should connect their recent mood to a broader pattern in their life.
      
      Example format: "You have been feeling [Mood] because deep down you are realizing [Deep Truth]. It is time to..."
      Keep it under 50 words. Mystical, earthy, validating.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "You are standing on the precipice of a quiet transformation; trust the slow unfolding of your life.";
  } catch (e) {
    return "The silence you are feeling is not emptiness, it is space for something new to grow. Your intuition has been trying to tell you something important—listen closely.";
  }
};

export const getAuraReading = async (archetype: string, mood?: string): Promise<AuraResult> => {
  try {
    const ai = getAI();
    const prompt = `
      Generate a mystical "Aura Reading" for a woman who is a "${archetype}".
      ${mood ? `She is currently feeling: "${mood}".` : ''}
      Assign a beautiful, specific color (like "Rose Quartz", "Midnight Indigo", "Sunlit Gold").
      
      Return JSON:
      1. colorName: The poetic name of the color.
      2. colorCode: A hex code that matches this color.
      3. meaning: 1 sentence on what this aura says about her energy today.
      4. prediction: 1 sentence prediction for the week.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            colorName: { type: Type.STRING },
            colorCode: { type: Type.STRING },
            meaning: { type: Type.STRING },
            prediction: { type: Type.STRING },
          },
          required: ["colorName", "colorCode", "meaning", "prediction"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as AuraResult;
  } catch (e) {
    console.warn("Aura API failed, using fallback", e);
    return getFallbackAura();
  }
};

export const analyzeMessage = async (message: string, context: string): Promise<MessageAnalysisResult> => {
  try {
    const ai = getAI();
    const prompt = `
      Analyze this text message: "${message}".
      Context provided by user: "${context}".
      
      The user is a woman asking what this message *really* means.
      Decode the subtext. Be honest but empathetic.
      
      Return JSON:
      1. hiddenEmotion: What the sender is likely feeling but not saying.
      2. realMeaning: The translation of the message.
      3. redFlagRating: "Safe", "Caution", or "Danger".
      4. advice: How she should respond (or not respond).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hiddenEmotion: { type: Type.STRING },
            realMeaning: { type: Type.STRING },
            redFlagRating: { type: Type.STRING, enum: ["Safe", "Caution", "Danger"] },
            advice: { type: Type.STRING },
          },
          required: ["hiddenEmotion", "realMeaning", "redFlagRating", "advice"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as MessageAnalysisResult;
  } catch (e) {
    console.warn("Message API failed, using fallback", e);
    return getFallbackMessageAnalysis();
  }
};

export const analyzeDream = async (dream: string): Promise<MessageAnalysisResult> => {
  try {
    const ai = getAI();
    const prompt = `
      Interpret this dream: "${dream}".
      Focus on psychological symbolism and hidden emotional needs.
      
      Return JSON (reusing structure for simplicity):
      1. hiddenEmotion: The subconscious emotion driving the dream.
      2. realMeaning: The symbolic interpretation.
      3. redFlagRating: Always return "Safe" for dreams unless it's a nightmare.
      4. advice: What the dream is telling her to do in waking life.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
         responseMimeType: "application/json",
         responseSchema: {
          type: Type.OBJECT,
          properties: {
            hiddenEmotion: { type: Type.STRING },
            realMeaning: { type: Type.STRING },
            redFlagRating: { type: Type.STRING },
            advice: { type: Type.STRING },
          },
          required: ["hiddenEmotion", "realMeaning", "redFlagRating", "advice"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as MessageAnalysisResult;
  } catch (e) {
    return {
        hiddenEmotion: "Unresolved processing of daily tension.",
        realMeaning: "Your mind is trying to solve a puzzle you ignore during the day.",
        redFlagRating: "Safe",
        advice: "Pay attention to where you felt powerless in the dream; that is where you need to claim power today."
    };
  }
};

export const analyzeFaceScan = async (base64Image: string): Promise<FaceScanResult> => {
  try {
    const ai = getAI();
    const mimeTypeMatch = base64Image.match(/^data:(image\/\w+);base64,/);
    const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/jpeg';
    const base64Data = base64Image.replace(/^data:image\/\w+;base64,/, "");

    const prompt = `
      Analyze the emotional energy of the person in this photo.
      Do NOT describe their physical appearance (eyes, hair, etc).
      Focus ONLY on the "vibe", the "hidden emotion", and the "soul energy".
      Also estimate numerical values for stress, fatigue, and confidence based on micro-expressions.
      Use the Barnum Effect to sound deep and intuitive.
      
      Return JSON:
      1. vibe: 2-3 words (e.g. "Radiant Exhaustion", "Hopeful Spark").
      2. hiddenEmotion: What they are hiding behind the smile (or lack thereof).
      3. romanticGlow: How magnetic they appear right now (e.g. "High", "Subtle", "Dormant").
      4. soulMessage: A short compliment about their spirit.
      5. stressLevel: number 0-100.
      6. emotionalFatigue: number 0-100.
      7. confidence: number 0-100.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                { inlineData: { mimeType: mimeType, data: base64Data } },
                { text: prompt }
            ]
        },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    vibe: { type: Type.STRING },
                    hiddenEmotion: { type: Type.STRING },
                    romanticGlow: { type: Type.STRING },
                    soulMessage: { type: Type.STRING },
                    stressLevel: { type: Type.NUMBER },
                    emotionalFatigue: { type: Type.NUMBER },
                    confidence: { type: Type.NUMBER }
                },
                required: ["vibe", "hiddenEmotion", "romanticGlow", "soulMessage", "stressLevel", "emotionalFatigue", "confidence"]
            }
        }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as FaceScanResult;

  } catch (e) {
    console.warn("Vision API failed, using fallback", e);
    return getFallbackFaceScan();
  }
}

export const analyzeShadowWork = async (archetype: string, struggle: string): Promise<string> => {
  try {
    const ai = getAI();
    const prompt = `
      The user is the "${archetype}" archetype. She is currently struggling with: "${struggle}".
      Provide a "Shadow Work" prompt and insight.
      Explain how her archetype's shadow (hidden side) is influencing this struggle.
      Be gentle but probing.
    `;
     const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Look into why you fear this feeling. What is it trying to protect you from?";
  } catch (e) {
    return "Your shadow is merely a part of you asking for attention. Listen to it without judgment. The struggle you feel is the friction of growth.";
  }
}

export const analyzeCompatibility = async (userArchetype: string, partnerArchetype: string): Promise<CompatibilityResult> => {
  try {
     const ai = getAI();
     const prompt = `
       Analyze the romantic compatibility between a "${userArchetype}" (Female) and a "${partnerArchetype}" (Partner).
       Return JSON:
       1. synergyScore: 0-100.
       2. emotionalConnection: A poetic description of their bond.
       3. challengeArea: Where they will clash.
       4. advice: How to make it work.
     `;
     
     const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              synergyScore: { type: Type.NUMBER },
              emotionalConnection: { type: Type.STRING },
              challengeArea: { type: Type.STRING },
              advice: { type: Type.STRING }
            },
            required: ["synergyScore", "emotionalConnection", "challengeArea", "advice"]
          }
        }
     });
     
     const text = response.text;
     if (!text) throw new Error("No response");
     return JSON.parse(text) as CompatibilityResult;
  } catch (e) {
     return {
        synergyScore: 82,
        emotionalConnection: "A meeting of two deep souls who see the world differently, yet understand the same language of the heart.",
        challengeArea: "Communication styles may differ during stress; one retreats while the other pursues.",
        advice: "Patience is the bridge between your worlds. Listen not to respond, but to understand."
     };
  }
}

export const analyzeConflict = async (situation: string, archetype: string): Promise<ConflictResult> => {
  try {
    const ai = getAI();
    const prompt = `
      The user (Archetype: ${archetype}) had this relationship situation/argument: "${situation}".
      Analyze it for red flags, boundaries, and hidden meanings.
      Use the Barnum Effect: Make it sound validating and insightful.
      
      Return JSON:
      1. boundaryStatus: "Respected", "Crossed", or "Undefined".
      2. analysis: What is really happening beneath the surface.
      3. hiddenMeaning: What the other person might be projecting or feeling.
      4. advice: How she should respond to protect her energy.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            boundaryStatus: { type: Type.STRING, enum: ["Respected", "Crossed", "Undefined"] },
            analysis: { type: Type.STRING },
            hiddenMeaning: { type: Type.STRING },
            advice: { type: Type.STRING }
          },
          required: ["boundaryStatus", "analysis", "hiddenMeaning", "advice"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as ConflictResult;
  } catch (e) {
    return {
      boundaryStatus: "Undefined",
      analysis: "There is a mismatch in expectations here. You are likely seeking clarity, while the situation is clouded by unspoken emotions.",
      hiddenMeaning: "They may be reacting to their own internal stress rather than your specific actions.",
      advice: "Step back and observe. Do not rush to fix what you did not break. Protect your peace first."
    };
  }
};

export const getInnerChildInsight = async (archetype: string, mood?: string): Promise<string> => {
  try {
    const ai = getAI();
    const prompt = `
      Generate a short, therapeutic "Inner Child Whisper" for a woman (Archetype: ${archetype}) who is feeling "${mood || 'uncertain'}".
      It should be soft, healing, and use the Barnum Effect (e.g., "Your inner child still fears...").
      Max 2 sentences.
    `;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Your inner child is safe now. You don't have to earn love by being perfect.";
  } catch (e) {
    return "Your inner child is asking for rest, not more achievement. It is safe to put down the heavy things you are carrying.";
  }
};

export const getDailyHoroscope = async (archetype: string, sign: string): Promise<string> => {
  try {
    const ai = getAI();
    const prompt = `
      Generate a daily horoscope for a "${sign}" who is a "${archetype}" archetype.
      Blend astrological traits with her psychological archetype.
      Keep it short, mystical, and empowering. Max 2 sentences.
    `;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || `As a ${sign}, your intuition is high today. Trust the process.`;
  } catch (e) {
    return `The cosmos is asking you to slow down. Your natural ${sign} resilience will guide you through this phase.`;
  }
};
